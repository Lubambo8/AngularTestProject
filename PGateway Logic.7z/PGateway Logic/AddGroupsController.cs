﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using Payment_gateway_frontEnd.Models.ManageGroupsModels;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using Payment_gateway_frontEnd.Models;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Payment_gateway_frontEnd.Controllers
{
    public class AddGroupsController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/group";
        private string userURL = "http://mplpgfe3:8443/api/user/username/";
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<IActionResult> AddGroupsAsync()
        {
            var username = HttpContext.Session.GetString("username");

            var token = HttpContext.Session.GetString("token");

            using(var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                //Request
                HttpRequestMessage requestUser = new HttpRequestMessage(HttpMethod.Get, userURL + username);

                requestUser.Content = new StringContent(JsonConvert.SerializeObject(""));
                requestUser.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                HttpResponseMessage responseUser = await client.SendAsync(requestUser);

                if(responseUser.IsSuccessStatusCode)
                {
                    var resultsUser = responseUser.Content.ReadAsStringAsync().Result;

                    UsersResultsDto resultsUserData = JsonConvert.DeserializeObject<UsersResultsDto>(resultsUser);

                    if (resultsUserData.roles[0].roleName.Equals("Administrator"))
                    {
                        AddGroupViewModel addGroupsView = new AddGroupViewModel();

                        var tempValue = TempData["ChangeOrderNum"];
                        bool validChangeOrderNumber;

                        if (tempValue == null)
                            validChangeOrderNumber = false;
                        else
                            validChangeOrderNumber = true;


                        if (!validChangeOrderNumber)
                        {
                            addGroupsView = new AddGroupViewModel
                            {

                                validChangeOrderNumber = false
                            };

                        }
                        else
                        {
                            addGroupsView = new AddGroupViewModel
                            {
                                UserGroupResultsDto = new UserGroupResultsDto
                                {
                                    changeOrderNumber = TempData["ChangeOrderNum"].ToString()
                                },


                                validChangeOrderNumber = true
                            };
                        }

                        return View("AddGroups", addGroupsView);
                    }
                    else
                    {
                        TempData["message"] = "Restricted! You do not have access to these functionality";
                        return RedirectToAction("ErrorMessage", "Error");
                    }

                }
                else
                {
                    TempData["message"] = "Restricted! You do not have access to these functionality";
                    return RedirectToAction("ErrorMessage", "Error");
                }


            }

            

           
        }

        public async Task<ActionResult> createGroup(string group, string folder, int exectusID, string ifs) 
        {
            try
            {
                string exectus = exectusID.ToString();

                if (!string.IsNullOrEmpty(group) && !string.IsNullOrEmpty(folder) && !string.IsNullOrEmpty(exectus) && !string.IsNullOrEmpty(ifs))
                {

                    var token = HttpContext.Session.GetString("token");

                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri(baseUrl);
                        client.DefaultRequestHeaders
                              .Accept
                              .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                        //Request
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, baseUrl + "/create");

                        bool ifsBool;
                        if(ifs == "Yes")
                            ifsBool = true;
                        else
                            ifsBool = false;

                        UserGroupResultsDto userGroupDto = new UserGroupResultsDto
                        {
                            groupName = group,
                            folder = folder,
                            exactus_user_id = exectusID,
                            ifs = ifsBool   

                        };

                        request.Content = new StringContent(JsonConvert.SerializeObject(userGroupDto));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);


                        if (response.IsSuccessStatusCode)
                        {
                            var results = response.Content.ReadAsStringAsync().Result;

                            UserGroupResultsDto resultsData = JsonConvert.DeserializeObject<UserGroupResultsDto>(results);

                            if (resultsData != null)
                            {
                                TempData["ChangeOrderNum"] = resultsData.changeOrderNumber;

                                return RedirectToAction("AddGroups", "AddGroups");
                            }

                        }

                        var result = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(result);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }

                }
            }
            catch 
            {
            }
            return View();
        
        }
    }
    
    
}
