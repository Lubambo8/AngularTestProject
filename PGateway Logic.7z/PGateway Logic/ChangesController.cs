﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Web.Helpers;
using Payment_gateway_frontEnd.Models.ManageChangesModels;
using System.Xml.Linq;
using Payment_gateway_frontEnd.Models;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ChangesController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/change/pending";

        private string updateBaseUrl = "http://mplpgfe3:8443/api/change/update";

        public List<SelectListItem> changesList = new List<SelectListItem>();
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<ActionResult> Changes(string message)
        {
            try
            {
                ViewBag.errorMessage = message;

                var token = HttpContext.Session.GetString("token");

                HttpContext.Session.Remove("changeList");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, baseUrl);

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        List<ChangesResultsDto> changesList = JsonConvert.DeserializeObject<List<ChangesResultsDto>>(results);

                        if (changesList.Any())
                        {
                            ChangesData changesData = new ChangesData
                            {
                                changesResultsList = changesList,
                            };

                            HttpContext.Session.SetString("changeList", JsonConvert.SerializeObject(changesList));

                            return View("Changes", changesData );
                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }

            }
            catch (Exception ex)
            {

            }
            
            return View();
        }

        public async Task<ActionResult> RejectChange(string rejectStatus, string rejectCONumber, string id)
        {

            try
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, updateBaseUrl);

                    if (!string.IsNullOrEmpty(id) && !string.IsNullOrEmpty(rejectStatus) && !string.IsNullOrEmpty(rejectCONumber))
                    {

                        ChangesDto changesDto = new ChangesDto
                        {

                            id = int.Parse(id),
                            status = rejectStatus

                        };


                        request.Content = new StringContent(JsonConvert.SerializeObject(changesDto));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);

                        string strchangeList = HttpContext.Session.GetString("changeList");

                        ChangesData changeList = new ChangesData
                        {
                            changesResultsList = JsonConvert.DeserializeObject<List<ChangesResultsDto>>(strchangeList)
                        };


                        if (response.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Changes", changeList);
                        }
                        else
                        {
                            var results = response.Content.ReadAsStringAsync().Result;
                            ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                            if (errorDto != null)
                            {
                                TempData["statuscode"] = errorDto.status;
                                TempData["message"] = errorDto.error;
                            }

                            return RedirectToAction("ErrorMessage", "Error");
                        }

                    }
                    else
                    {
                        string errorMessage = "Invalid change number";
                        return RedirectToAction("Changes", "Changes", new { message = errorMessage });

                    }

                }
            }
            catch (Exception ex)
            {

            }

            return RedirectToAction("SystemAdmin", "SystemAdmin");
        }

        public async Task<ActionResult> ApproveChange(string approveStatus, string approveCONumber, string ID)
        {
            try
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, updateBaseUrl);

                    if (!string.IsNullOrEmpty(ID) && !string.IsNullOrEmpty(approveStatus) && !string.IsNullOrEmpty(approveCONumber))
                    {

                        ChangesDto changesDto = new ChangesDto
                        {

                            id = int.Parse(ID),
                            status = approveStatus

                        };


                        request.Content = new StringContent(JsonConvert.SerializeObject(changesDto));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);

                        string strchangeList = HttpContext.Session.GetString("changeList");

                        ChangesData changeList = new ChangesData
                        {
                            changesResultsList = JsonConvert.DeserializeObject<List<ChangesResultsDto>>(strchangeList)
                        };

                        if (response.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Changes", changeList);
                        }
                        else
                        {
                            var results = response.Content.ReadAsStringAsync().Result;
                            ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                            if (errorDto != null)
                            {
                                TempData["statuscode"] = errorDto.status;
                                TempData["message"] = errorDto.error;
                            }

                            return RedirectToAction("ErrorMessage", "Error");
                        }

                    }
                    else
                    {
                        string errorMessage = "Invalid change number";
                        return RedirectToAction("Changes", "Changes", new { message = errorMessage });

                    }

                }
            }
            catch (Exception ex)
            {

            }

            return RedirectToAction("SystemAdmin", "SystemAdmin");

        }
    }
   
}
