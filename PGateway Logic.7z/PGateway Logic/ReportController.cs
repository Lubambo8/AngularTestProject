﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models.ManagePaymentModels;
using Payment_gateway_frontEnd.Models;
using System.Net.Http.Headers;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using Payment_gateway_frontEnd.Models.ManageGroupsModels;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using Payment_gateway_frontEnd.Models.PGFDbContexts;
using Payment_gateway_frontEnd.Models.ViewModels;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ReportController : Controller
    {
        private string baseUrlHistory = "http://mplpgfe3:8443/api/upload/file/history/";
        private string baseUrlRejected = "http://mplpgfe3:8443/api/upload/file/rejected/";
        private string baseUrlApproved = "http://mplpgfe3:8443/api/upload/file/approved/";
        private string groupBaseUrl = "http://mplpgfe3:8443/api/group/";

        private readonly ILogger<ReportController> _logger;

        private readonly PGFEDbContext _context;

        public ReportController(ILogger<ReportController> logger, PGFEDbContext context)
        {
             _context = context;
             _logger = logger;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<IActionResult> Report()
        {
            try
            {

                var token = HttpContext.Session.GetString("token");
                int groupID = int.Parse(HttpContext.Session.GetString("groupId"));

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrlHistory);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    
                    HttpRequestMessage requestRejected = new HttpRequestMessage(HttpMethod.Get, baseUrlRejected + groupID);
                    HttpRequestMessage requestApproved = new HttpRequestMessage(HttpMethod.Get, baseUrlApproved + groupID);

                    
                    requestRejected.Content = new StringContent(JsonConvert.SerializeObject(""));
                    requestRejected.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");
                    requestApproved.Content = new StringContent(JsonConvert.SerializeObject(""));
                    requestApproved.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    
                    HttpResponseMessage responseRejected = await client.SendAsync(requestRejected);
                    HttpResponseMessage responseApproved = await client.SendAsync(requestApproved);

                    if (responseRejected.IsSuccessStatusCode && responseApproved.IsSuccessStatusCode)
                    {
                        
                        var resultsRejected = responseRejected.Content.ReadAsStringAsync().Result;
                        var resultsApproved = responseApproved.Content.ReadAsStringAsync().Result;

                        
                        List<PaymentPendingResultsDto> paymentsListRejected = JsonConvert.DeserializeObject<List<PaymentPendingResultsDto>>(resultsRejected);
                        List<PaymentPendingResultsDto> paymentsListApproved = JsonConvert.DeserializeObject<List<PaymentPendingResultsDto>>(resultsApproved);

                        if (paymentsListRejected.Any() || paymentsListApproved.Any())
                        {
                            PaymentsData paymentsData = new PaymentsData()
                            {
                                
                                ApprovedPaymentList = paymentsListApproved,
                                RejectedPaymentList = paymentsListRejected
                            };

                            return View("Report", paymentsData);
                        }

                    }
                    else
                    {
                        var results = responseApproved.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }

            }
            catch (Exception ex)
            {

            }

            return View();
        }

        public async Task<IActionResult> AuditReport()
        {
            try
            {
                var token = HttpContext.Session.GetString("token");
                int groupID = int.Parse(HttpContext.Session.GetString("groupId"));

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(baseUrlHistory);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    HttpRequestMessage requestHistory = new HttpRequestMessage(HttpMethod.Get, baseUrlHistory + groupID);

                    requestHistory.Content = new StringContent(JsonConvert.SerializeObject(""));
                    requestHistory.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage responseHistory = await client.SendAsync(requestHistory);

                    if (responseHistory.IsSuccessStatusCode)
                    {
                        var resultsHistory = responseHistory.Content.ReadAsStringAsync().Result;

                        List<PaymentPendingResultsDto> paymentsListHistory = JsonConvert.DeserializeObject<List<PaymentPendingResultsDto>>(resultsHistory);
                        if (paymentsListHistory.Any())
                        {
                            var Users = _context.users.ToList();

                            PaymentsData paymentsData = new PaymentsData()
                            {
                                HistoryPaymentList = paymentsListHistory,
                                Users = _context.users.ToList()

                            };


                            ReportViewModel reportViewModel = new ReportViewModel();
                            reportViewModel.ReportDate = DateTime.Now.ToString("MM/dd/yyyy");
                            reportViewModel.PaymentsData = paymentsData;

                            return View(reportViewModel);
                        }
                    }
                    else
                    {
                        var results = responseHistory.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }

                    
                }

            }
            catch (Exception)
            {

                
            }
            return View();
        }

        public string GetGroupNamr(int userId)
        {
            var username = "";

            if (userId > 0)
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(groupBaseUrl);
                    client.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);



                    //Request
                    HttpRequestMessage Userrequest = new HttpRequestMessage(HttpMethod.Get, groupBaseUrl + userId);

                    Userrequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                    Userrequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = client.Send(Userrequest);


                    if (response.IsSuccessStatusCode)
                    {

                        var results = response.Content.ReadAsStringAsync().Result;

                        UserGroupResultsDto groupObject = JsonConvert.DeserializeObject<UserGroupResultsDto>(results);

                        if (groupObject != null)
                        {
                            username = groupObject.groupName;

                            return username;
                        }


                    }
                }





            }


            return username;
        }


    }
}
