﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using System.Net.Http.Headers;

namespace Payment_gateway_frontEnd.Controllers
{
    public class OneTimePinController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/auth/";

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public IActionResult OneTimePin(string message)
        {
            var mobileNumber = HttpContext.Session.GetString("cellphone");
            var lastDigitsNumber = "";

            if (mobileNumber != null) {

                lastDigitsNumber = mobileNumber.ToString().Substring((mobileNumber.Length - 4), 4);

            }

            HttpContext.Session.SetString("lastDigits", lastDigitsNumber);

            ViewBag.errorMessage = message;
            return View();
        }

        [HttpPost]
         public async Task<ActionResult> VerifyOTP(string OTP)
        {

            try
            {

                if (!string.IsNullOrEmpty(OTP))
                {

                    var stringOTP = OTP.ToLower();
                    var username = HttpContext.Session.GetString("username");
                    var accessToken = HttpContext.Session.GetString("accessToke");

                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri(baseUrl);
                        client.DefaultRequestHeaders
                              .Accept
                              .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);



                        //Request
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl + "otp");

                        OTP oneTimePin = new OTP
                        {

                            otp = stringOTP,
                            username = username
                        };

                        request.Content = new StringContent(JsonConvert.SerializeObject(oneTimePin));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);



                        if (response.IsSuccessStatusCode)
                        {

                            var results = response.Content.ReadAsStringAsync().Result;

                            ResultsOTP OTPresultsData = JsonConvert.DeserializeObject<ResultsOTP>(results);

                            var roles = new List<string>();

                            foreach (var rolename in OTPresultsData.roleResponses.ToList())
                            {

                                roles.Add(rolename.roleName.ToString());
                                HttpContext.Session.SetString("roles", rolename.roleName);
                            }

                            if (OTPresultsData.verifyOtpStatus)
                            {
                                HttpContext.Session.SetString("token", OTPresultsData.token);

                                return RedirectToAction("Landing", "Landing");

                            }
                            else
                            {
                                return RedirectToAction("OneTimePin", "OneTimePin");
                            }



                        }
                        else
                        {
                            

                            string errorMessage = "Invalid OTP! Try Again";
                            return RedirectToAction("OneTimePin", "OneTimePin", new { message = errorMessage });

                        }

                    }


                }
                else
                {
                    string errorMessage = "Please enter OTP";
                    return RedirectToAction("OneTimePin", "OneTimePin", new { message = errorMessage });
                }

            }
            catch(Exception ex)
            {
                return RedirectToAction("OneTimePin", "OneTimePin");
            }
            
        }

        [HttpPost]
        public async Task<ActionResult> resendOTP()
        {
            try
            {
                var username = HttpContext.Session.GetString("username");
                var accessToken = HttpContext.Session.GetString("accessToke");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);



                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl + "resend/otp");

                    ResendOTP oneTimePin = new ResendOTP
                    {
                        username = username
                    };

                    request.Content = new StringContent(JsonConvert.SerializeObject(oneTimePin));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);



                    if (response.IsSuccessStatusCode)
                    {

                        var results = response.Content.ReadAsStringAsync().Result;

                        var message = "OTP Sent";

                        return RedirectToAction("OneTimePin", "OneTimePin", new { message});

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);


                        
                        return RedirectToAction("OneTimePin", "OneTimePin", new { message = errorDto.error });
                        
                    }

                }



            }
            catch (Exception ex)
            {
                return RedirectToAction("OneTimePin", "OneTimePin");
            }

        }
        
    
    }
}
