﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using System.Net.Http.Headers;

namespace Trial.Controllers
{
    public class LandingController : Controller
    {

        private string baseUrl = "http://mplpgfe3:8443/api/group/groupName/";
        private string groupsBaseUrl = "http://mplpgfe3:8443/api/group/username/";

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }
        public async Task<IActionResult> Landing()
        {

            var username = HttpContext.Session.GetString("username");

            if (!string.IsNullOrEmpty(username))
            {

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, groupsBaseUrl + username);


                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);


                    if (response.IsSuccessStatusCode)
                    {

                        var results = response.Content.ReadAsStringAsync().Result;

                        List<UserGroupResultsDto> groupResults = JsonConvert.DeserializeObject<List<UserGroupResultsDto>>(results);

                        if (groupResults.Any() && groupResults.Count > 1)
                        {

                            LandingGroupData groupViewData = new LandingGroupData
                            {
                                UserGroupResult = groupResults,
                                DisplayList = true,
                                hasMultipleGroups = true
                                
                            };

                            return View("Landing", groupViewData);

                        }else if(groupResults.Any() && groupResults.Count == 1)
                        {

                            foreach(var group in groupResults)
                            {
                                HttpContext.Session.SetString("groupId", group.id.ToString());
                                HttpContext.Session.SetString("groupName", group.groupName);
                            }

                            LandingGroupData groupViewData = new LandingGroupData
                            {
                                UserGroupResult = groupResults,
                                DisplayList = true,
                                hasMultipleGroups = false

                            };

                            return View("Landing", groupViewData);

                        }

                    }
                }


            }


            return View();
        }

        public async Task<IActionResult> getGroupName(string groupName)
        {

            if (!string.IsNullOrEmpty(groupName))
            {

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, baseUrl + groupName);


                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);


                    if (response.IsSuccessStatusCode)
                    {

                        var results = response.Content.ReadAsStringAsync().Result;

                        UserGroupResultsDto groupResultData = JsonConvert.DeserializeObject<UserGroupResultsDto>(results);

                        if (groupResultData != null)
                        {                        
                         
                            HttpContext.Session.SetString("groupId", groupResultData.id.ToString());
                            HttpContext.Session.SetString("groupName", groupResultData.groupName);

                            LandingGroupData groupViewData = new LandingGroupData
                            {
                                UserGroupResultData = groupResultData,
                                DisplayList = false
                            };

                            return View("Landing", groupViewData);

                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }
                    }
                }


            }


            return View();
        }


    }
}
