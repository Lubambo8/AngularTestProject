﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models.ManagePaymentModels;
using Payment_gateway_frontEnd.Models;
using System.Net.Http.Headers;
using Payment_gateway_frontEnd.Models.ViewModels;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using System.Numerics;
using Microsoft.Extensions.Primitives;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using NuGet.Common;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ProcessedFilesController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/upload/file/process/";
        private string viewBaseUrl = "http://mplpgfe3:8443/api/file/";
        private string sendPOPUrl = "http://mplpgfe3:8443/api/send/pop";
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<IActionResult> ProcessedFiles()
        {
            try
            {

                var token = HttpContext.Session.GetString("token");
                int groupID = int.Parse(HttpContext.Session.GetString("groupId"));

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, baseUrl + groupID);

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        List<ProcessedPaymentResults> paymentsList = JsonConvert.DeserializeObject<List<ProcessedPaymentResults>>(results);

                        List<ProcessedPaymentResults> paymentListData = new List<ProcessedPaymentResults>();

                        if (paymentsList.Any())
                        {

                            PaymentsData paymentsData = new PaymentsData()
                            {
                                ProcessedPayments = paymentsList,
                            };



                            return View("ProcessedFiles", paymentsData);
                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }

            }
            catch (Exception ex)
            {

            }
            return View();
        }

        public async Task<IActionResult> viewFile(string fileName)
        {

            if (!string.IsNullOrEmpty(fileName))
            {
                var token = HttpContext.Session.GetString("token");
                int groupID = int.Parse(HttpContext.Session.GetString("groupId"));

                bool showPopUP = false;

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);


                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, viewBaseUrl + groupID + "?filename=" + fileName);

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");


                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        string[] strHeadings = results.Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);

                        if (strHeadings.Length > 0)
                        {

                            //Declaring variables 

                            var HRID = "";
                            var userID = "";
                            var userCode = "";
                            var generationNum = "";
                            var fileDate = "";
                            var indicator = "";
                            var strfileName = "";

                            var IRID = "";
                            var recordCounter = "";
                            var IRUserID = "";
                            var IRUserCode = "";
                            var IRMode = "";
                            var IRUserRef = "";
                            var IRStatementRef = "";
                            var IRActionDate = "";
                            var norminatedAccountNumber = "";
                            var IRBranchCode = "";
                            var IRAccountType = "";
                            var IRAccountHolder = "";
                            var IRAmount = "";
                            var IREntryClass = "";
                            var IRTransactionRef = "";

                            var TRFieldID = "";
                            var TRDate = "";
                            var TRRecordCount = "";
                            var TRNumberOfDebits = "";
                            var TRNumberOfCredits = "";
                            var TRValueOfDebits = "";
                            var TRValueOfCredits = "";
                            var TRHashTotals = "";

                            ViewFileObject fileObject = new ViewFileObject();
                            List<IRObject> iRObjectList = new List<IRObject>();
                            IRObject IRobject = new IRObject();

                            foreach (string line in strHeadings)
                            {

                                if (line.ToString().Contains("HR"))
                                {

                                    string[] HRList = line.ToString().Split('|');

                                    HRID = HRList[0];
                                    userID = HRList[1];
                                    userCode = HRList[2];
                                    generationNum = HRList[3];
                                    fileDate = HRList[4];
                                    indicator = HRList[5];
                                    strfileName = HRList[6];

                                }
                                else if (line.ToString().Contains("IR"))
                                {
                                    string[] IRList = line.ToString().Split('|');

                                    IRID = IRList[0];
                                    recordCounter = IRList[1];
                                    IRUserID = IRList[2];
                                    IRUserCode = IRList[3];
                                    IRMode = IRList[4];
                                    IRUserRef = IRList[5];
                                    IRStatementRef = IRList[6];
                                    IRActionDate = IRList[7];
                                    norminatedAccountNumber = IRList[8];
                                    IRBranchCode = IRList[9];
                                    IRAccountType = IRList[10];
                                    IRAccountHolder = IRList[11];
                                    IRAmount = IRList[12];
                                    IREntryClass = IRList[13];
                                    IRTransactionRef = IRList[14];

                                    //object

                                    Decimal bigDecimalCents = Decimal.Parse(IRAmount);
                                    Decimal bigDecimalRands = bigDecimalCents / 100;
                                    decimal decAmount = Math.Round(bigDecimalRands, 2);
                                    var strAmount = decAmount.ToString();

                                    IRobject = new IRObject
                                    {
                                        IRID = IRID,
                                        recordCounter = recordCounter,
                                        IRUserID = IRUserID,
                                        IRUserCode = IRUserCode,
                                        IRMode = IRMode,
                                        IRUserRef = IRUserRef,
                                        IRStatementRef = IRStatementRef,
                                        IRActionDate = IRActionDate,
                                        norminatedAccountNumber = norminatedAccountNumber,
                                        IRBranchCode = IRBranchCode,
                                        IRAccountType = IRAccountType,
                                        IRAccountHolder = IRAccountHolder,
                                        IRAmount = strAmount,
                                        IREntryClass = IREntryClass,
                                        IRTransactionRef = IRTransactionRef

                                    };



                                }
                                else
                                {
                                    string[] TRList = line.ToString().Split('|');

                                    TRFieldID = TRList[0];
                                    TRDate = TRList[1];
                                    TRRecordCount = TRList[2];
                                    TRNumberOfDebits = TRList[3];
                                    TRNumberOfCredits = TRList[4];
                                    TRValueOfDebits = TRList[5];
                                    TRValueOfCredits = TRList[6];
                                    TRHashTotals = TRList[7];

                                }

                                //avaoiding storing empty Object
                                if (IRobject.IRID != null)
                                {
                                    iRObjectList.Add(IRobject);
                                    IRobject.IRID = null;

                                }

                            }


                            fileObject = new ViewFileObject
                            {
                                HRID = HRID,
                                userID = userID,
                                userCode = userCode,
                                generationNum = generationNum,
                                fileDate = fileDate,
                                indicator = indicator,
                                strfileName = strfileName,
                                TRFieldID = TRFieldID,
                                TRDate = TRDate,
                                TRRecordCount = TRRecordCount,
                                TRNumberOfDebits = TRNumberOfDebits,
                                TRNumberOfCredits = TRNumberOfCredits,
                                TRValueOfDebits = TRValueOfDebits,
                                TRValueOfCredits = TRValueOfCredits,
                                TRHashTotals = TRHashTotals,
                                IRObjects = iRObjectList
                            };

                            var sendPOPUP = TempData["POPSent"];
                            ViewFileDataModel viewFile = new ViewFileDataModel();

                            if (sendPOPUP == null)
                            {
                                showPopUP = false;
                            }
                            else
                            {
                                showPopUP = true;
                            }

                            if (!showPopUP)
                            {
                                viewFile = new ViewFileDataModel()
                                {
                                    viewFileObject = fileObject,
                                    POPSent = false
                                };
                            }
                            else
                            {
                                viewFile = new ViewFileDataModel()
                                {
                                    viewFileObject = fileObject,
                                    POPSent = true
                                };

                            }


                            HttpContext.Session.SetString("fileObject", JsonConvert.SerializeObject(viewFile));
                            return RedirectToAction("POPViewFile", viewFile);

                        }



                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");

                    }
                }

            }
            return View("ProcessedFiles");
        }

        public IActionResult POPViewFile()
        {
            ViewFileDataModel viewFile = new ViewFileDataModel();
            var sessionString = HttpContext.Session.GetString("fileObject");
            viewFile = JsonConvert.DeserializeObject<ViewFileDataModel>(sessionString);
            var valueDeterminer = TempData["POPSent"];
            if (valueDeterminer == null)
                viewFile.POPSent = false;
            else
                viewFile.POPSent = true;
            TempData.Clear();

            return View(viewFile);
        }
   
    
        public async Task<IActionResult> generatePOP(string vendorName, string amount, string dateOfPayment, string branchCode, string accountNumber, string reference, string fileName)
        {
            try
            {
                using (var client = new HttpClient())
                {

                    var token = HttpContext.Session.GetString("token");

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Populating Object

                    var emailAddress = HttpContext.Session.GetString("username") + "@africanbank.co.za";

                    ProofOfPaymentDto proofOfPaymentDto = new ProofOfPaymentDto {

                        dateOfPayment = dateOfPayment,
                        recipient = vendorName,
                        amount = amount.ToString(),
                        branchCode = branchCode,
                        accountNumber = accountNumber,
                        paidby = "African Bank Limited",
                        recipientReference = reference,
                        email = emailAddress,
                        bank = "African Bank Limited",
                        username = "African Bank Limited"

                    };

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, sendPOPUrl);

                    request.Content = new StringContent(JsonConvert.SerializeObject(proofOfPaymentDto));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        ViewFileDataModel viewFile = new ViewFileDataModel();
                        var sessionString = HttpContext.Session.GetString("fileObject");
                        viewFile.viewFileObject = JsonConvert.DeserializeObject<ViewFileObject>(sessionString);

                        TempData["POPSent"] = results;

                        return RedirectToAction("POPViewFile", viewFile);

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");

                    }
                }
            

            }catch (Exception ex)
            {
                return RedirectToAction("ErrorMessage", "Error");
            }

            
        }
    }
}
