﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using System.Net.Http.Headers;

namespace Payment_gateway_frontEnd.Controllers
{
    public class LoginController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/auth/";


        public IActionResult Login(string message)
        {
            ViewBag.errorMessage = message;
            return View();

        }

        public async Task<ActionResult> VerifyUser(string username, string password)
        {

            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Request
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl+ "login");

                UserLogin loginDetails = new UserLogin
                {
                    username = username,
                    password = password,

                };

                request.Content = new StringContent(JsonConvert.SerializeObject(loginDetails));
                request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                HttpResponseMessage response = await client.SendAsync(request);


                if (response.IsSuccessStatusCode)
                {
                    var results = response.Content.ReadAsStringAsync().Result;

                    ResultDto resultsData = JsonConvert.DeserializeObject<ResultDto>(results);

                    if (resultsData != null)
                    {
                        if (resultsData.loginStatus)
                        {

                            //storing username and token to session

                            HttpContext.Session.SetString("username", username);
                            HttpContext.Session.SetString("accessToke", resultsData.accessToken);
                            HttpContext.Session.SetString("cellphone", resultsData.mobileNumber);

                            return RedirectToAction("OneTimePin", "OneTimePin");

                        }

                    }
                    else
                    {
                        return RedirectToAction("Login", "Login");
                    }
                }
                else
                {
                    
                  string errorMessage = "Invalid Username or Password";
                    return RedirectToAction("Login", "Login", new { message = errorMessage });
                }

            }

            return RedirectToAction("/");
        }
    }
}
