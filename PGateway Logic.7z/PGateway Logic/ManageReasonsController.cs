﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using Payment_gateway_frontEnd.Models;
using System.Net.Http.Headers;
using Payment_gateway_frontEnd.Models.ManageReasonsModels;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ManageReasonsController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/reason";

        public async Task<ActionResult> ManageReasons()
        {
            try
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, baseUrl);

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        UserReasonResultsDto[] userReasonList = JsonConvert.DeserializeObject<UserReasonResultsDto[]>(results);

                        if (userReasonList.Length > 0)
                        {

                            return View("ManageRoles", userReasonList);
                        }

                    }
                    else
                    {
                        //var results = response.Content.ReadAsStringAsync().Result;
                        //ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        //if (errorDto != null)
                        //{
                        //    TempData["statuscode"] = errorDto.status;
                        //    TempData["message"] = errorDto.error;
                        //}

                        //return RedirectToAction("ErrorMessage", "Error");
                    }
                }

            }
            catch (Exception ex)
            {

            }

            return View();
        }
          
    }
}
