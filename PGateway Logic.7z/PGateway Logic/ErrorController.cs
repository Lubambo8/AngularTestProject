﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using System.Net;
using System.Net.Http.Headers;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ErrorController : Controller
    {
        

        enum StatusCode
        {
            
            Exists500 = 500,
            Exist400 = 400
        }

        public IActionResult Error(string message)
        {
            ViewBag.errorMessage = message;
            return View();
        }
            
        public IActionResult ErrorMessage()
        {
            var errorMessage = TempData["message"];

            if(errorMessage == null)
            {
                errorMessage = "Restricted/Error! Restricted Access/Unable to complete action";
            }
            
            //string errorMessage = "";
            //switch(statusCode)
            //{
            //    case (int)StatusCode.Exists500:
            //        errorMessage = "User already exists";
            //        break;
            //    case (int)StatusCode.Length400:
            //        errorMessage = "length must be between 5 and 20";
            //        break;
                
            //}

            TempData.Clear();
            return RedirectToAction("Error", "Error", new {message = errorMessage });

        }
    }
}
