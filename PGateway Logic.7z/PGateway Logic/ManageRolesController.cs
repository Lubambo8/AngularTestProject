﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using System.Net.Http.Headers;
using System.Web.Helpers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ManageRolesController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/role";

        public List<SelectListItem> roleList = new List<SelectListItem>();

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<ActionResult> ManageRoles()
        {
            try
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, baseUrl + "s");

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        UserRoleResultsDto[] userRoleList = JsonConvert.DeserializeObject<UserRoleResultsDto[]>(results);

                        if (userRoleList.Length > 0)
                        {

                            return View("ManageRoles", userRoleList);
                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }

            }
            catch (Exception ex)
            {

            }
            
            return View();
        }
    }
}
