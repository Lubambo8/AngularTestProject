﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using Payment_gateway_frontEnd.Models.ManageUploadModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using System;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;

namespace Payment_gateway_frontEnd.Controllers
{
    public class PaymentUploadController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/upload/file/";
        private string uploadBaseUrl = "http://mplpgfe3:8443/api/upload/file";

        public List<String> fileNames = new List<string>();
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<IActionResult> PaymentUpload()
        {

            var token = HttpContext.Session.GetString("token");
            var groupId = HttpContext.Session.GetString("groupId");
            UploadViewModel uploadObj = new UploadViewModel();

            
            var TempDataBoolean = TempData["activateModal"];
            var TempDataUploadStatus = TempData["uploadStatus"];
            bool modalActivate;
            bool uploadStatus;
            var message = (string)TempData["strMessage"];

            if (TempDataBoolean == null)
                modalActivate = false;
            else
                modalActivate = true;


            if(TempDataUploadStatus == null)
                uploadStatus = false;
            else
                uploadStatus = (bool)TempDataUploadStatus;


            uploadObj = new UploadViewModel
            {
                uploadVETStatus = uploadStatus,
                activateModal = modalActivate,
                strMessage = message
            };



            

            if (groupId == null)
            {
                groupId = "0";
            }

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var currentDate = DateTime.Now.ToString("dd-MM-yyyy");



                HttpRequestMessage uploadRequest = new HttpRequestMessage(HttpMethod.Get, baseUrl + int.Parse(groupId) + "?queryDate=" + currentDate);

                uploadRequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                uploadRequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                HttpResponseMessage upResults = await client.SendAsync(uploadRequest);

                if (upResults.IsSuccessStatusCode)
                {
                    //getting results from the RestApi (JSON formart)
                    var uploResponse = upResults.Content.ReadAsStringAsync().Result;
                    var uploResultsObj = JsonConvert.DeserializeObject<string[]>(uploResponse);


                    if (uploResultsObj != null)
                    {

                        if (uploResultsObj.Length > 0)
                        {

                            uploadObj.haveFiles = true;

                            if (uploResultsObj.Any())
                            {

                                foreach (var uplo in uploResultsObj)
                                {
                                    fileNames.Add(uplo);
                                }
                            }


                            uploadObj.files = fileNames;

                        }
                        else
                        {
                            //End loop if the asset list is empty
                            baseUrl = string.Empty;
                        }




                    }
                    else
                    {
                        //End loop if we get an error
                        baseUrl = string.Empty;
                        return View("PaymentUpload", "PaymentUpload");
                    }
                }
                else
                {
                    var results = upResults.Content.ReadAsStringAsync().Result;
                    ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                    if (errorDto != null)
                    {
                        TempData["statuscode"] = errorDto.status;
                        TempData["message"] = errorDto.error;
                    }

                    return RedirectToAction("ErrorMessage", "Error");

                }

                HttpContext.Session.SetString("fileNames", JsonConvert.SerializeObject(fileNames));

            }

            return View("PaymentUpload", uploadObj);
        }
    

        public async Task<IActionResult> UploadPaymentFile(string upload)
        {

            if (!string.IsNullOrEmpty(upload))
            {

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    UploadPaymentFile uploadObj = new UploadPaymentFile
                    {

                        groupID = int.Parse(HttpContext.Session.GetString("groupId")),
                        fileName = upload,
                        action = "Upload"
                    };

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, uploadBaseUrl);

                    request.Content = new StringContent(JsonConvert.SerializeObject(uploadObj));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    client.Timeout = TimeSpan.FromMinutes(10);


                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        UploadResultsDto resultsData = JsonConvert.DeserializeObject<UploadResultsDto>(results);

                        if(resultsData != null)
                        {
                            TempData["uploadStatus"] = resultsData.processFileStatus;
                            TempData["activateModal"] = true;
                            TempData["strMessage"] = "No Errors Found in VET File";
                            return RedirectToAction("PaymentUpload", "PaymentUpload");
                        }

                        

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["uploadStatus"] = response.IsSuccessStatusCode;
                            TempData["activateModal"] = true;
                            TempData["strMessage"] = errorDto.error;

                        }

                        return RedirectToAction("PaymentUpload", "PaymentUpload");

                    }

                }


                
            }

            return View();
        }
    
    }
}
