﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.ManageReasonsModels;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using System.Net.Http.Headers;

namespace Payment_gateway_frontEnd.Controllers
{
    public class AddReasonController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/reason/create";
        private string userURL = "http://mplpgfe3:8443/api/user/username/";
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }
        public async Task<IActionResult> AddReason()
        {
            var username = HttpContext.Session.GetString("username");

            var token = HttpContext.Session.GetString("token");

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUrl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                //Request
                HttpRequestMessage requestUser = new HttpRequestMessage(HttpMethod.Get, userURL + username);

                requestUser.Content = new StringContent(JsonConvert.SerializeObject(""));
                requestUser.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                HttpResponseMessage responseUser = await client.SendAsync(requestUser);

                if (responseUser.IsSuccessStatusCode)
                {
                    var resultsUser = responseUser.Content.ReadAsStringAsync().Result;

                    UsersResultsDto resultsUserData = JsonConvert.DeserializeObject<UsersResultsDto>(resultsUser);

                    if (resultsUserData.roles[0].roleName.Equals("Administrator"))
                    {
                        AddReasonsViewModel addReasonsView = new AddReasonsViewModel();

                        var tempValue = TempData["ChangeOrderNum"];
                        bool validChangeOrderNumber;

                        if (tempValue == null)
                            validChangeOrderNumber = false;
                        else
                            validChangeOrderNumber = true;

                        if (!validChangeOrderNumber)
                        {
                            addReasonsView = new AddReasonsViewModel
                            {

                                validChangeOrderNumber = false
                            };

                        }
                        else
                        {
                            addReasonsView = new AddReasonsViewModel
                            {

                                UserReasonResultsDto = new UserReasonResultsDto
                                {
                                    changeOrderNumber = TempData["ChangeOrderNum"].ToString()
                                },


                                validChangeOrderNumber = true
                            };
                        }

                        return View("AddReason", addReasonsView);
                    }
                    else
                    {
                        TempData["message"] = "Restricted! You do not have access to these functionality";
                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }
                else
                {
                    TempData["message"] = "Restricted! You do not have access to these functionality";
                    return RedirectToAction("ErrorMessage", "Error");
                }
            }



        }

        public async Task<ActionResult> createReason(string reasonname)
        {
            try
            {

                if (!string.IsNullOrEmpty(reasonname))
                {

                    var token = HttpContext.Session.GetString("token");

                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri(baseUrl);
                        client.DefaultRequestHeaders
                              .Accept
                              .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                        //Request
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, baseUrl);

                        UserReasonDto userReasonDto = new UserReasonDto
                        {
                            reasonName = reasonname

                        };
                      
                        request.Content = new StringContent(JsonConvert.SerializeObject(userReasonDto));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);


                        if (response.IsSuccessStatusCode)
                        {
                            var results = response.Content.ReadAsStringAsync().Result;

                            UserReasonResultsDto resultsData = JsonConvert.DeserializeObject<UserReasonResultsDto>(results);

                            if (resultsData != null)
                            {
                                TempData["ChangeOrderNum"] = resultsData.reasonName;

                                return RedirectToAction("AddReason", "AddReason");
                            }

                        }


                        var result = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(result);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }
                        return Content("Reason name not added");
                        //return RedirectToAction("ErrorMessage", "Error");
                    }

                }



              
            }
            catch (Exception ex)
            {

            }

            return View();

        }
    }
}
