﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Payment_gateway_frontEnd.Controllers
{
    public class LogoutController : Controller
    {

        public override void OnActionExecuting(ActionExecutingContext context)
        {

            HttpContext.Session.Clear();

            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");

            }

            base.OnActionExecuting(context);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login", "Login");
        }
    }
}
