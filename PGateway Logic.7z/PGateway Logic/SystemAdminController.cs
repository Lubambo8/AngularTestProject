﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Payment_gateway_frontEnd.Controllers
{
    public class SystemAdminController : Controller
    {

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public IActionResult SystemAdmin()
        {
            return View();
        }
    }
}
