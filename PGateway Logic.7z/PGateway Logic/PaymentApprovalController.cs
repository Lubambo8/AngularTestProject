﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models.ManageChangesModels;
using Payment_gateway_frontEnd.Models;
using System.Net.Http.Headers;
using Payment_gateway_frontEnd.Models.ManagePaymentModels;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using Payment_gateway_frontEnd.Models.ManageUploadModels;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.VisualBasic;
using Microsoft.EntityFrameworkCore.Metadata;
using Payment_gateway_frontEnd.Models.PGFDbContexts;

namespace Payment_gateway_frontEnd.Controllers
{
    public class PaymentApprovalController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/upload/file/pending/";
        private string userBaseUrl = "http://mplpgfe3:8443/api/user/";
        private string UpdateBaseUrl = "http://mplpgfe3:8443/api/upload/file/update";
        private string viewBaseUrl = "http://mplpgfe3:8443/api/file/";

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        public async Task<IActionResult> PaymentApproval()
        {
            PaymentApprovalViewModel paymentApprovalViewModel = new PaymentApprovalViewModel();
            try
            {
               
                var token = HttpContext.Session.GetString("token");
                int groupID = int.Parse(HttpContext.Session.GetString("groupId"));

                using (var client = new HttpClient())
                {
                    

                    var tempValue = TempData["successApproval"];
                    if (tempValue != null)
                        paymentApprovalViewModel.successApprove = true;
                    else
                        paymentApprovalViewModel.successApprove = false;

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, baseUrl + groupID);

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        List<PaymentPendingResultsDto> paymentsList = JsonConvert.DeserializeObject<List<PaymentPendingResultsDto>>(results);

                        List<PaymentPendingResultsDto> paymentListData = new List<PaymentPendingResultsDto>();

                        if (paymentsList.Any())
                        {
                            foreach (var payment in paymentsList)
                            {

                                var paymentdateString = payment.modifiedDate.Split("T")[0];
                                var status = "";
                                if (payment.paymentFileStatus.Equals("WAITING_FIRST_APPROVER"))
                                {
                                    status = "Waiting 1st Approver";

                                }
                                else
                                    status = "Waiting 2nd Approver";


                                    
                                PaymentPendingResultsDto resultsDto = new PaymentPendingResultsDto
                                {
                                    id = payment.id,
                                    fileName = payment.fileName,
                                    paymentFileStatus = status,
                                    uploader = payment.uploader, //GetUserName(int.Parse(payment.uploaderId)),
                                    uploadedDate = payment.uploadedDate,
                                    firstReleaser = payment.firstReleaser, //GetUserName(int.Parse(payment.firstReleaserId)),
                                    firstReleaseDate = payment.firstReleaseDate,
                                    secondReleaser = payment.secondReleaser, //GetUserName(int.Parse(payment.secondReleaserId)),
                                    secondReleaseDate = payment.secondReleaseDate,
                                    groupId = payment.groupId,
                                    totalTransactions = payment.totalTransactions,
                                    totalAmount = payment.totalAmount,
                                    rejectedDate = payment.rejectedDate,
                                    createdDate = payment.createdDate,
                                    modifiedDate = paymentdateString,
                                    recordStatusInfod = payment.recordStatusInfod,
                                };
                                paymentListData.Add(resultsDto);
                            }




                            paymentApprovalViewModel.PendingPayResultsList = paymentListData;
                            


                            HttpContext.Session.SetString("paymentData", JsonConvert.SerializeObject(paymentApprovalViewModel));
                            

                            return View("PaymentApproval", paymentApprovalViewModel);
                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }

            }
            catch (Exception ex)
            {
                return RedirectToAction("ErrorMessage", "Error");
            }

            return View(paymentApprovalViewModel);
        }
    
        public async Task<IActionResult> approveFile(string fileName)
        {

            if(!string.IsNullOrEmpty(fileName))
            {
                    
                var stringObject = HttpContext.Session.GetString("paymentData");

                var strFileName = fileName.Split(new char[0])[0];

                var paymentsObject = JsonConvert.DeserializeObject<PaymentsData>(stringObject);

                var filteredFileObject = paymentsObject.PendingPayResultsList.Where(x => x.fileName == strFileName).FirstOrDefault();


                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    if (filteredFileObject != null)
                    {

                        UpdatePaymentModel updatePayment = new UpdatePaymentModel
                        {
                            id = filteredFileObject.id,
                            paymentFileStatus = "APPROVED"
                        };

                        //Request
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, UpdateBaseUrl);

                        request.Content = new StringContent(JsonConvert.SerializeObject(updatePayment));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");


                        HttpResponseMessage response = await client.SendAsync(request);

                        if (response.IsSuccessStatusCode)
                        {

                            var results = response.Content.ReadAsStringAsync().Result;
                            TempData["successApproval"] = results;

                            return RedirectToAction("PaymentApproval", "PaymentApproval");


                        }
                        else
                        {
                            var results = response.Content.ReadAsStringAsync().Result;
                            ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                            if (errorDto != null)
                            {
                                TempData["statuscode"] = errorDto.status;
                                TempData["message"] = errorDto.error;
                            }

                            return RedirectToAction("PaymentApproval", "PaymentApproval");

                        }
                    }
                }

            }

            return View("PaymentApproval");
        }

        public async Task<IActionResult> rejectFile(string file,string reason)
        {

            if (!string.IsNullOrEmpty(file) || !string.IsNullOrEmpty(reason))
            {

                var stringObject = HttpContext.Session.GetString("paymentData");

                var strFileName = file.Split(new char[0])[0];

                var paymentsObject = JsonConvert.DeserializeObject<PaymentsData>(stringObject);

                var filteredFileObject = paymentsObject.PendingPayResultsList.Where(x => x.fileName == strFileName).FirstOrDefault();

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    if (filteredFileObject != null)
                    {

                        List<Reason> reasonList = new List<Reason>
                        {

                            new Reason
                            {
                                reasonName = reason,
                            }

                        };

                        UpdatePaymentModel updatePayment = new UpdatePaymentModel
                        {
                            id = filteredFileObject.id,
                            paymentFileStatus = "REJECTED",
                            reasons = reasonList
                        };

                        //Request
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, UpdateBaseUrl);

                        request.Content = new StringContent(JsonConvert.SerializeObject(updatePayment));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");


                        HttpResponseMessage response = await client.SendAsync(request);

                        if (response.IsSuccessStatusCode)
                        {
                            var results = response.Content.ReadAsStringAsync().Result;

                            TempData.Clear();
                            return RedirectToAction("PaymentApproval", "PaymentApproval");

                        }
                        else
                        {
                            var results = response.Content.ReadAsStringAsync().Result;
                            ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                            if (errorDto != null)
                            {
                                TempData["statuscode"] = errorDto.status;
                                TempData["message"] = errorDto.error;
                            }

                            return RedirectToAction("ErrorMessage", "Error");

                        }
                    }
                }

            }

            TempData.Clear();
            return View("PaymentApproval");
        }

        public IActionResult PaymentViewFile()
        {
            ViewFileDataModel viewFile = new ViewFileDataModel();
            var sessionString = HttpContext.Session.GetString("fileObject");
            viewFile = JsonConvert.DeserializeObject<ViewFileDataModel>(sessionString);

            return View(viewFile);
        }


        public async Task<IActionResult> viewFile(string fileName)
        {

            if (!string.IsNullOrEmpty(fileName))
            {
                var token = HttpContext.Session.GetString("token");
                int groupID = int.Parse(HttpContext.Session.GetString("groupId"));

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);


                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, viewBaseUrl + groupID + "?filename=" + fileName);

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");


                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        string[] strHeadings = results.Split(Environment.NewLine,StringSplitOptions.RemoveEmptyEntries);

                        if(strHeadings.Length > 0)
                        {

                            //Declaring variables 

                            var HRID ="";
                            var userID = "";
                            var userCode = "";
                            var generationNum = "";
                            var fileDate = "";
                            var indicator = "";
                            var strfileName = "";

                            var IRID = "";
                            var recordCounter = "";
                            var IRUserID = "";
                            var IRUserCode = "";
                            var IRMode = "";
                            var IRUserRef = "";
                            var IRStatementRef = "";
                            var IRActionDate = "";
                            var norminatedAccountNumber = "";
                            var IRBranchCode = "";
                            var IRAccountType = "";
                            var IRAccountHolder = "";
                            var IRAmount = "";
                            var IREntryClass = "";
                            var IRTransactionRef = "";

                            var TRFieldID = "";
                            var TRDate = "";
                            var TRRecordCount = "";
                            var TRNumberOfDebits = "";
                            var TRNumberOfCredits = "";
                            var TRValueOfDebits = "";
                            var TRValueOfCredits = "";
                            var TRHashTotals = "";

                            ViewFileObject fileObject = new ViewFileObject();
                            List<IRObject> iRObjectList = new List<IRObject>();
                            IRObject IRobject = new IRObject();

                            foreach (string line in strHeadings)
                            {
                                string[] HRList = line.ToString().Split('|');

                                if (HRList[0].ToString().Contains("HR"))
                                {

                                    HRID = HRList[0];
                                    userID = HRList[1];
                                    userCode = HRList[2];
                                    generationNum = HRList[3];
                                    fileDate = HRList[4];
                                    indicator = HRList[5];
                                    strfileName = fileName;//HRList[6];

                                }

                                string[] IRList = line.ToString().Split('|');

                                if (IRList[0].ToString().Contains("IR"))
                                {
                                    

                                    IRID = IRList[0];
                                    recordCounter = IRList[1];
                                    IRUserID = IRList[2];
                                    IRUserCode = IRList[3];
                                    IRMode = IRList[4];
                                    IRUserRef = IRList[5];
                                    IRStatementRef = IRList[6];
                                    IRActionDate = IRList[7];
                                    norminatedAccountNumber = IRList[8];
                                    IRBranchCode = IRList[9];
                                    IRAccountType = IRList[10];
                                    IRAccountHolder = IRList[11];
                                    IRAmount = IRList[12];
                                    IREntryClass = IRList[13];
                                    IRTransactionRef = IRList[14];


                                    Decimal bigDecimalCents = Decimal.Parse(IRAmount);
                                    Decimal bigDecimalRands = bigDecimalCents / 100;
                                    decimal decAmount = Math.Round(bigDecimalRands, 2);
                                    var strAmount = decAmount.ToString();

                                    //object

                                    IRobject = new IRObject
                                    {
                                        IRID = IRID,
                                        recordCounter = recordCounter,
                                        IRUserID = IRUserID,
                                        IRUserCode = IRUserCode,
                                        IRMode = IRMode,
                                        IRUserRef = IRUserRef,
                                        IRStatementRef = IRStatementRef,
                                        IRActionDate = IRActionDate,
                                        norminatedAccountNumber = norminatedAccountNumber,
                                        IRBranchCode = IRBranchCode,
                                        IRAccountType = IRAccountType,
                                        IRAccountHolder = IRAccountHolder,
                                        IRAmount = strAmount,
                                        IREntryClass = IREntryClass,
                                        IRTransactionRef = IRTransactionRef

                                    };



                                }
                                string[] TRList = line.ToString().Split('|');


                                if (TRList[0].ToString().Contains("TR"))
                                {
                                   

                                    TRFieldID = TRList[0];
                                    TRDate = TRList[1];
                                    TRRecordCount = TRList[2];
                                    TRNumberOfDebits = TRList[3];
                                    TRNumberOfCredits = TRList[4];
                                    TRValueOfDebits = TRList[5];
                                    TRValueOfCredits = TRList[6];
                                    TRHashTotals = TRList[7];

                                }

                                //avaoiding storing empty Object
                                if(IRobject.IRID != null)
                                {
                                    iRObjectList.Add(IRobject);
                                    IRobject.IRID = null;

                                }

                            }

                            
                            fileObject = new ViewFileObject
                            {
                                HRID = HRID,
                                userID = userID,
                                userCode = userCode,
                                generationNum = generationNum,
                                fileDate = fileDate,
                                indicator = indicator,
                                strfileName = strfileName,
                                TRFieldID = TRFieldID,
                                TRDate = TRDate,
                                TRRecordCount = TRRecordCount,
                                TRNumberOfDebits = TRNumberOfDebits,
                                TRNumberOfCredits = TRNumberOfCredits,
                                TRValueOfDebits = TRValueOfDebits,
                                TRValueOfCredits = TRValueOfCredits,
                                TRHashTotals = TRHashTotals,
                                IRObjects = iRObjectList
                            };


                            ViewFileDataModel viewFile = new ViewFileDataModel()
                            {
                                viewFileObject = fileObject,
                            };

                            HttpContext.Session.SetString("fileObject", JsonConvert.SerializeObject(viewFile));

                            return RedirectToAction("PaymentViewFile", viewFile);

                        }



                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");

                    }
                }

            }
            return View("PaymentApproval");
        }


        public string GetUserName(int userId)
        {
            var username = "";

            if(userId > 0)
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                            .Accept
                            .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);



                    //Request
                    HttpRequestMessage Userrequest = new HttpRequestMessage(HttpMethod.Get, userBaseUrl + userId);

                    Userrequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                    Userrequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = client.Send(Userrequest);


                    if (response.IsSuccessStatusCode)
                    {

                        var results = response.Content.ReadAsStringAsync().Result;

                        UsersResultsDto userObject = JsonConvert.DeserializeObject<UsersResultsDto>(results);

                        if(userObject != null)
                        {
                            username = userObject.name + " " + userObject.surname;

                            return username;
                        }


                    }
                }


                


            }


            return username;
        }
    }
}
