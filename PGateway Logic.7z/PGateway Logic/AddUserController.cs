﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using Payment_gateway_frontEnd.Models.ManageGroupsModels;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using System.Net.Http.Headers;
using System.Numerics;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Web.Helpers;

namespace Payment_gateway_frontEnd.Controllers
{
    public class AddUserController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/user/";

        private string getGroupbaseUrl = "http://mplpgfe3:8443/api/group/";

        public string baseRoleUrl = "http://mplpgfe3:8443/api/roles";

        public string groupBaseURl = "http://mplpgfe3:8443/api/groups";

        public List<SelectListItem> roleList = new List<SelectListItem>();
        public List<SelectListItem> groupList = new List<SelectListItem>();

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }



        public async Task<ActionResult> AddUser()
        {
            try
            {
                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    HttpRequestMessage roleRequest = new HttpRequestMessage(HttpMethod.Get, baseRoleUrl);
                    HttpRequestMessage groupRequest = new HttpRequestMessage(HttpMethod.Get, groupBaseURl);


                    roleRequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                    roleRequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    groupRequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                    groupRequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage RoleResponse = await client.SendAsync(roleRequest);
                    HttpResponseMessage groupResponse = await client.SendAsync(groupRequest);

                    if (RoleResponse.IsSuccessStatusCode || groupResponse.IsSuccessStatusCode)
                    {
                        var roleResults = RoleResponse.Content.ReadAsStringAsync().Result;
                        var groupResults = groupResponse.Content.ReadAsStringAsync().Result;

                        UserRoleResultsDto[] userRoleList = JsonConvert.DeserializeObject<UserRoleResultsDto[]>(roleResults);
                        UserGroupResultsDto[] userGrouproupList = JsonConvert.DeserializeObject<UserGroupResultsDto[]>(groupResults);

                        roleList = userRoleList.ToList().Select(role => new SelectListItem
                        {
                            Value = role.roleName,
                            Text = role.roleName
                        }).ToList();

                        groupList = userGrouproupList.ToList().Select(group => new SelectListItem
                        {
                            Value = group.id.ToString(),
                            Text = group.groupName

                        }).ToList();

                        UserRoleData userRoleData = new UserRoleData
                        {
                            RoleSelectListItem = roleList,
                            GroupSelectListItem = groupList
                        };

                        AddUserViewModel userViewModel = new AddUserViewModel();

                        var tempValue = TempData["ChangeOrderNum"];
                        bool validChangeOrderNumber;

                        if (tempValue == null)
                            validChangeOrderNumber = false;
                        else
                            validChangeOrderNumber = true;





                        if (!validChangeOrderNumber)
                        {
                            userViewModel = new AddUserViewModel
                            {
                                AddUserResultsDto = null,
                                UserRoleData = userRoleData,
                                validChangeOrderNumber = false
                            };

                        }
                        else
                        {
                            userViewModel = new AddUserViewModel
                            {
                                AddUserResultsDto = new AddUserResultsDto
                                {
                                    changeOrderNumber = TempData["ChangeOrderNum"].ToString()
                                },

                                UserRoleData = userRoleData,
                                validChangeOrderNumber = true
                            };
                        }

                        return View("AddUser", userViewModel);


                    }
                    else
                    {
                        var results = RoleResponse.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }

                }


            }
            catch (Exception ex)
            {

            }
            return View();
        }

        public async Task<ActionResult> createUser(string name, string surname, string username, string usermail, string[] group, string role, long limit)
        {
            try
            {

                if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(surname) && !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(usermail) && !string.IsNullOrEmpty(role))
                {
                    var token = HttpContext.Session.GetString("token");

                    using (var client = new HttpClient())
                    {

                        client.BaseAddress = new Uri(baseUrl);
                        client.DefaultRequestHeaders
                              .Accept
                              .Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                        //Request
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, baseUrl + "create");

                        AddUser userObj = new AddUser();
                        List<Role> roleList = new List<Role>();
                        List<UserGroupResultsDto> groupUserDto = new List<UserGroupResultsDto>();

                        foreach (var groupID in group)
                        {


                            HttpRequestMessage getGrouprequest = new HttpRequestMessage(HttpMethod.Get, getGroupbaseUrl + groupID);

                            getGrouprequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                            getGrouprequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                            HttpResponseMessage getGroupResponse = await client.SendAsync(getGrouprequest);

                            if (getGroupResponse.IsSuccessStatusCode)
                            {
                                var groupResults = getGroupResponse.Content.ReadAsStringAsync().Result;

                                UserGroupResultsDto userGroupObj = JsonConvert.DeserializeObject<UserGroupResultsDto>(groupResults);

                                if (userGroupObj != null)
                                {

                                    UserGroupResultsDto groupObject = new UserGroupResultsDto
                                    {
                                        id = userGroupObj.id,
                                        groupName = userGroupObj.groupName,
                                        folder = userGroupObj.folder,
                                        exactus_user_id = userGroupObj.exactus_user_id,
                                        ifs = false
                                    };

                                    groupUserDto.Add(groupObject);
                                }

                                roleList = new List<Role>
                                {
                                    new Role{

                                        roleName = role
                                    }
                                };

                            }
                            else
                            {
                                var statusCode = (int)getGroupResponse.StatusCode;
                                TempData["statuscode"] = statusCode;
                                return RedirectToAction("ErrorMessage", "Error");
                            }


                        }

                        userObj = new AddUser
                        {
                            username = username,
                            name = name,
                            surname = surname,
                            email = usermail,
                            active = true,
                            groups = groupUserDto,
                            roles = roleList
                        };

                        request.Content = new StringContent(JsonConvert.SerializeObject(userObj));
                        request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);


                        if (response.IsSuccessStatusCode)
                        {
                            var results = response.Content.ReadAsStringAsync().Result;

                            AddUserResultsDto addUserObjResults = JsonConvert.DeserializeObject<AddUserResultsDto>(results);

                            if (addUserObjResults != null)
                            {


                                TempData["ChangeOrderNum"] = addUserObjResults.changeOrderNumber;

                                return RedirectToAction("AddUser", "AddUser");

                            }

                            return RedirectToAction("SystemAdmin", "SystemAdmin");


                        }
                        else
                        {
                            var results = response.Content.ReadAsStringAsync().Result;
                            ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                            if (errorDto != null)
                            {
                                TempData["statuscode"] = errorDto.status;
                                TempData["message"] = errorDto.error;
                            }

                            return RedirectToAction("ErrorMessage", "Error");
                        }
                    }

                }
            }
            catch (Exception ex)
            {

            }

            return View();
        }
    }

}
