﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using Payment_gateway_frontEnd.Models;
using Payment_gateway_frontEnd.Models.AuthenticationModels;
using Payment_gateway_frontEnd.Models.ManageGroupsModels;
using Payment_gateway_frontEnd.Models.ManageRolesModels;
using Payment_gateway_frontEnd.Models.ManageUserModels;
using Payment_gateway_frontEnd.Models.ViewModels;
using System.Data;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc.Filters;
using Payment_gateway_frontEnd.Services;
using System.Security.AccessControl;

namespace Payment_gateway_frontEnd.Controllers
{
    public class ManageUsersController : Controller
    {
        private string baseUrl = "http://mplpgfe3:8443/api/user";

        private string getUsersUrl = "http://mplpgfe3:8443/api/users";

        private string getGroupbaseUrl = "http://mplpgfe3:8443/api/group/groupName/";

        public string baseRoleUrl = "http://mplpgfe3:8443/api/roles";

        public string groupBaseURl = "http://mplpgfe3:8443/api/groups";

        public string addUserToGroupUrl = "http://mplpgfe3:8443/api/group/user_to_group";

        public List<SelectListItem> roleList = new List<SelectListItem>();
        public List<SelectListItem> groupList = new List<SelectListItem>();

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }
            
            base.OnActionExecuting(context);

        }



        public async Task<ActionResult> ManageUsers()
        {
            try
            {
                var token = HttpContext.Session.GetString("token");
                
                HTTPServices hTTPServices = new HTTPServices();
                var response = await hTTPServices.HttpGetMethod(token, getUsersUrl);
                
                if (response != "unsuccessful")
                {
                    
                    var results =  response;
                    
                    
                    var RoleResponse = await hTTPServices.HttpGetMethod(token, baseRoleUrl);
                    

                    UsersResultsDto[] userList = JsonConvert.DeserializeObject<UsersResultsDto[]>(results);

                    if (RoleResponse != "unsuccessful")
                    {
                        var roleResults = RoleResponse;

                        UserRoleResultsDto[] userRoleList = JsonConvert.DeserializeObject<UserRoleResultsDto[]>(roleResults);

                        roleList = userRoleList.ToList().Select(role => new SelectListItem
                        {
                            Value = role.roleName,
                            Text = role.roleName
                        }).ToList();
                    }
                    var groupResponse = await hTTPServices.HttpGetMethod(token, groupBaseURl);

                    if (groupResponse != "unsuccessful")
                    {
                        var groupResults = groupResponse;

                        UserGroupResultsDto[] userGrouproupList = JsonConvert.DeserializeObject<UserGroupResultsDto[]>(groupResults);

                        groupList = userGrouproupList.ToList().Select(group => new SelectListItem
                        {
                            Value = group.groupName,
                            Text = group.groupName

                        }).ToList();

                    }
                    
                    if (userList.Length > 0)
                    {
                        UserRoleData userRoleData = new UserRoleData
                        {
                            userRoleResultsLIst = userList,
                            RoleSelectListItem = roleList,
                            GroupSelectListItem = groupList,

                        };

                        ManageUsersViewModel_ manageuserViewModel = new ManageUsersViewModel_();

                        var tempValue = TempData["ChangeOrderNum"];
                        bool validChangeOrderNumber;

                        if (tempValue == null)
                            validChangeOrderNumber = false;
                        else
                            validChangeOrderNumber = true;

                        if (!validChangeOrderNumber)
                        {
                            manageuserViewModel = new ManageUsersViewModel_
                            {
                                AddUserResultsDto = null,
                                UserRoleData = userRoleData,
                                validChangeOrderNumber = false
                            };

                        }
                        else
                        {
                            manageuserViewModel = new ManageUsersViewModel_
                            {
                                AddUserResultsDto = new AddUserResultsDto
                                {
                                    changeOrderNumber = TempData["ChangeOrderNum"].ToString()
                                },

                                UserRoleData = userRoleData,
                                validChangeOrderNumber = true
                            };
                        }
                        return View("ManageUsers", manageuserViewModel);
                    }

                }
                else
                {
                    var results = response;
                    ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                    if (errorDto != null)
                    {
                        TempData["statuscode"] = errorDto.status;
                        TempData["message"] = errorDto.error;
                    }

                    return RedirectToAction("ErrorMessage", "Error");
                }



            }catch (Exception ex)
            {

            }
            return View();
        }
    
        public async Task<ActionResult> UpdateUser(string username, string userId, string name, string surname, string email, string role, string[] group)
        {
            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(surname) && !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(userId))
            {

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, baseUrl + "/update");
                    AddUser userObj = new AddUser();
                    List<Role> roleList = new List<Role>();
                    List<UserGroupResultsDto> groupUserDto = new List<UserGroupResultsDto>();

                    foreach (var groupID in group) {


                        HttpRequestMessage getGrouprequest = new HttpRequestMessage(HttpMethod.Get, getGroupbaseUrl + groupID);

                        getGrouprequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                        getGrouprequest.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                        HttpResponseMessage getGroupResponse = await client.SendAsync(getGrouprequest);

                        if (getGroupResponse.IsSuccessStatusCode)
                        {
                            var groupResults = getGroupResponse.Content.ReadAsStringAsync().Result;

                            UserGroupResultsDto userGroupObj = JsonConvert.DeserializeObject<UserGroupResultsDto>(groupResults);

                            if (userGroupObj != null)
                            {

                                UserGroupResultsDto groupObject = new UserGroupResultsDto
                                {
                                    id = userGroupObj.id,
                                    groupName = userGroupObj.groupName,
                                    folder = userGroupObj.folder,
                                    exactus_user_id = userGroupObj.exactus_user_id,
                                    ifs = false
                                };

                                groupUserDto.Add(groupObject);
                            }

                            roleList = new List<Role>
                            {
                                 new Role{

                                    roleName = role
                                 }
                            };
                           
                        }
                        else
                        {
                            var statusCode = (int)getGroupResponse.StatusCode;
                            TempData["statuscode"] = statusCode;
                            return RedirectToAction("ErrorMessage", "Error");
                        }


                    }

                    userObj = new AddUser
                    {
                        username = username,
                        name = name,
                        surname = surname,
                        email = email,
                        active = true,
                        groups = groupUserDto,
                        roles = roleList
                    };

                    request.Content = new StringContent(JsonConvert.SerializeObject(userObj));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        AddUserResultsDto addUserObjResults = JsonConvert.DeserializeObject<AddUserResultsDto>(results);

                        if (addUserObjResults != null)
                        {


                            TempData["ChangeOrderNum"] = addUserObjResults.changeOrderNumber;

                            return RedirectToAction("ManageUsers", "ManageUsers");

                        }

                        return RedirectToAction("SystemAdmin", "SystemAdmin");


                    }
                    else
                    {
                        var statusCode = (int)response.StatusCode;
                        TempData["statuscode"] = statusCode;
                        return RedirectToAction("ErrorMessage", "Error");
                    }


                }
            }
                
            return RedirectToAction("ManageUsers", "ManageUsers");

        }

        public async Task<ActionResult> DeactivateUser(string Id, string user)
        {
            if (!string.IsNullOrEmpty(Id))
            {

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, baseUrl + "/update");

                    UpdateUser userObj = new UpdateUser
                    {
                        active = false,
                        username = user
                    };

                    request.Content = new StringContent(JsonConvert.SerializeObject(userObj));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);


                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        AddUserResultsDto addUserObjResults = JsonConvert.DeserializeObject<AddUserResultsDto>(results);

                        if (addUserObjResults != null)
                        {
                            TempData["ChangeOrderNum"] = addUserObjResults.changeOrderNumber;

                            return RedirectToAction("ManageUsers", "ManageUsers");

                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }
            }

            return RedirectToAction("ManageUsers", "ManageUsers");

        }

        public async Task<ActionResult> ActivateUser(string ID, string userid)
        {
            if (!string.IsNullOrEmpty(ID))
            {

                var token = HttpContext.Session.GetString("token");

                using (var client = new HttpClient())
                {

                    client.BaseAddress = new Uri(baseUrl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Put, baseUrl + "/update");

                    UpdateUser userObj = new UpdateUser
                    {
                        active = true,
                        username = userid

                    };

                    request.Content = new StringContent(JsonConvert.SerializeObject(userObj));
                    request.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/json");

                    HttpResponseMessage response = await client.SendAsync(request);


                    if (response.IsSuccessStatusCode)
                    {
                        var results = response.Content.ReadAsStringAsync().Result;

                        AddUserResultsDto addUserObjResults = JsonConvert.DeserializeObject<AddUserResultsDto>(results);

                        if (addUserObjResults != null)
                        {
                            TempData["ChangeOrderNum"] = addUserObjResults.changeOrderNumber;

                            return RedirectToAction("ManageUsers", "ManageUsers");

                        }

                    }
                    else
                    {
                        var results = response.Content.ReadAsStringAsync().Result;
                        ErrorViewResultsDto errorDto = JsonConvert.DeserializeObject<ErrorViewResultsDto>(results);

                        if (errorDto != null)
                        {
                            TempData["statuscode"] = errorDto.status;
                            TempData["message"] = errorDto.error;
                        }

                        return RedirectToAction("ErrorMessage", "Error");
                    }
                }
            }

            return RedirectToAction("ManageUsers", "ManageUsers");

        }


    }
}
