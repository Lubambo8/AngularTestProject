﻿using Microsoft.AspNetCore.Mvc;

namespace Payment_gateway_frontEnd.Controllers
{
    public class TransactionSearchController : Controller
    {
        public IActionResult TransactionSearch()
        {
            return View();
        }
    }
}
