﻿using Microsoft.AspNetCore.Mvc;

namespace Payment_gateway_frontEnd.Controllers
{
    public class GroupProfileController : Controller
    {
        public IActionResult GroupProfile()
        {
            return View();
        }
    }
}
