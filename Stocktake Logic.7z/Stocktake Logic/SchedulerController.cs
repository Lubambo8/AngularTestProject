﻿using Microsoft.AspNetCore.Mvc;

namespace StockTakeModuleWebApp.Controllers
{
    public class SchedulerController : Controller
    {
        public IActionResult Scheduler()
        {
            return View();
        }
    }
}
