﻿using Microsoft.AspNetCore.Mvc;

namespace StockTakeModuleWebApp.Controllers
{
    public class ErrorController : Controller
    {
        public IActionResult Error()
        {
            return View();
        }
    }
}
