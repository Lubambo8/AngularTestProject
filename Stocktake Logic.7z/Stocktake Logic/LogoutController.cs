﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using StockTakeModuleWebApp.Models.AuthenModel;
using StockTakeModuleWebApp.Services;

namespace StockTakeModuleWebApp.Controllers
{
    public class LogoutController : Controller
    {
        private readonly IStocktakeService<User> _logoutService;
        public LogoutController(IStocktakeService<User> logoutService)
        {
            _logoutService = logoutService;
        }

        

        public async Task<ActionResult> Logout()
        {

            if (HttpContext.Session.GetString("username") != null)
            {

                var username = HttpContext.Session.GetString("username").ToString().ToLower();
                var specUser = await _logoutService.FindByUsernameAsync(username);

                User user = new User();
                user.Id = specUser.Id;
                user.UserName = specUser.UserName;
                user.LogginDate = specUser.LogginDate;
                user.isLoggedIn = false;

                await _logoutService.ReplaceOneAsync(user);

                HttpContext.Session.Clear();
                
            }

            return RedirectToAction("Login", "Login");

        }

    }
}
