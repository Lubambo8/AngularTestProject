﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using MongoDB.Driver;
using Nancy.Json;
using Newtonsoft.Json;
using StockTakeModuleWebApp.Models.AuthenModel;
using StockTakeModuleWebApp.Services;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;
using System.Web;
using Microsoft.AspNetCore.Http;
using System.Net.Http;

namespace StockTakeModuleWebApp.Controllers
{
    public class LoginController : Controller
    {

        string Baseurl = "https://api.prd.africanbank.net";

        

        private readonly IStocktakeService<User> _loginService;
        public LoginController(IStocktakeService<User> loginService)
        {
            _loginService = loginService;
        }


        public IActionResult Login(string message)
        {
            ViewBag.errorMessage = message;
            return View();
        }

        public async Task<ActionResult> AutheticateUser(string uname, string psw)
        {
            ViewBag.uname = uname;


            User userLog = new User();

            string username = uname.ToString().ToLower();

            var user = await _loginService.FindByUsernameAsync(username);

            //if (user == null)
            //{
            //    userLog.isLoggedIn = false;
            //}
            //else
            //    userLog.isLoggedIn = user.isLoggedIn;

            //if(userLog.isLoggedIn == true)
            //{
            //    //userLog.Id = user.Id;
            //    //userLog.UserName = user.UserName;
            //    //userLog.LogginDate= user.LogginDate;
            //    //userLog.isLoggedIn = false;
            //    //await _loginService.ReplaceOneAsync(userLog);
            //    //string errorMessage = "Concurrent session detected! Please re-login";

            //    return RedirectToAction("Landing", "Landing" /*new { message = errorMessage }*/);
            //}
            //else
            //{
                
            //}


            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Request
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://api.prd.africanbank.net/rest/abPsCEPService/security/auth/ldap/authenticate");


                // Initializing the content request objects
                ContentDataObj serviceHeaderRequest = new ContentDataObj
                {

                    channel = "Web",
                    system = "EBANKIT",
                    user = "Mobile",
                    serviceOperation = "CLIENT",
                    uniqueTransactionID = "null",
                    sessionId = "36cb0eaa-ab96-1234-abc"


                };

                ContentRequestDto contentReq = new ContentRequestDto
                {
                    password = psw,
                    username = uname,
                    domain = "africanbank.net",
                    serviceHeaderRequest = serviceHeaderRequest

                };

                ContentRequesBody contentRequest = new ContentRequesBody
                {
                    content = contentReq
                };


                //adding hearders and content to the request

                request.Content = new StringContent(JsonConvert.SerializeObject(contentRequest));
                request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                //sending the request and getting response

                HttpResponseMessage res = await client.SendAsync(request);

                if (res.IsSuccessStatusCode)
                {



                    //getting results from the RestApi (JSON formart)
                    var response = res.Content.ReadAsStringAsync().Result;

                    //Converting from Json then assign to the response object
                    ResponseDto responseDto = JsonConvert.DeserializeObject<ResponseDto>(response);



                    if (responseDto.results != null)
                    {
                        if (responseDto.results.authenticated)
                        {

                            var isTamUser = false;
                            var isAdminUser = false;
                            var isStockTakeUser = false;
                            var isStockTakeBranchUser = false;
                            var isBranchManager = false;
                            var isHeadOfficeManager = false;


                            TempData["userDetails"] = responseDto.results.username;

                            //Checking branch users, its not head office
                            if (responseDto.results.branchCode != "2852")
                            {
                                //check if its a TAM user
                                if (responseDto.results.groups.Contains("StockTakeTAMs"))
                                {
                                    isTamUser = true;
                                }
                                else if (responseDto.results.groups.Contains("ABTAMS"))
                                {
                                    isTamUser = true;
                                }
                                else
                                {
                                    isStockTakeBranchUser = true;
                                }


                            }
                            else if (responseDto.results.branchCode == "2852")
                            {
                                //checking Admins
                                if (responseDto.results.groups.Contains("StockTake Admins"))
                                {
                                    isAdminUser = true;
                                }
                                //checking managers
                                else if (responseDto.results.groups.Contains("StockTake Power User Midrand"))
                                {
                                    isHeadOfficeManager = true;
                                }
                                else
                                //its a normal users
                                {
                                    isStockTakeUser = true;
                                }
                            }

                            ////connecting to MongoDB
                            User userModel = new User();

                            if (user != null)
                            {
                                userModel.Id = user.Id;
                                userModel.UserName = user.UserName;
                                userModel.LogginDate = DateTime.Now;
                                userModel.isLoggedIn = true;
                                await _loginService.ReplaceOneAsync(userModel);
                            }
                            else
                            {
                                userModel.UserName = uname.ToString().ToLower();
                                userModel.isLoggedIn = true;
                                userModel.LogginDate = DateTime.Now;

                                await _loginService.InsertOneAsync(userModel);
                            }




                            HttpContext.Session.SetString("username", responseDto.results.username.ToString().ToLower());

                            HttpContext.Session.SetString("TamUser", isTamUser.ToString());
                            HttpContext.Session.SetString("isAdminUser", isAdminUser.ToString());
                            HttpContext.Session.SetString("IsStockTakeUser", isStockTakeUser.ToString());
                            HttpContext.Session.SetString("isHeadOfficeManager", isHeadOfficeManager.ToString());
                            HttpContext.Session.SetString("isStockTakeBranchUser", isStockTakeBranchUser.ToString());

                            TempData["username"] = uname.ToString();
                            return RedirectToAction("Landing", "Landing");

                        }
                        else
                        {
                            string errorMessage = "Invalid Username/Password";


                            return RedirectToAction("Login", "Login", new { message = errorMessage });

                        }


                    }


                    return RedirectToAction("Login", "Login");

                }
                else
                {
                    return RedirectToAction("Login", "Login");
                }





            }

        }

    }
   

}

