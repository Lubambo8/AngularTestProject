﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;

namespace StockTakeModuleWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DownloadController : ControllerBase
    {

        private readonly IWebHostEnvironment environment;
        public DownloadController(IWebHostEnvironment hostEnvironment)
        {
            environment = hostEnvironment;
        }

        [HttpGet("downloadIT")]
        public IActionResult downloadITAssets()
        {
            var filepath = Path.Combine(environment.WebRootPath, "templates", "IT Assets.xlsx");
            return File(System.IO.File.ReadAllBytes(filepath), "IT/xlsx", System.IO.Path.GetFileName(filepath));
        }

        [HttpGet("downloadNonIT")]
        public IActionResult downloadNonITAssets()
        {
            var filepath = Path.Combine(environment.WebRootPath, "templates", "Minor assets - Non IT Assets.xlsx");
            return File(System.IO.File.ReadAllBytes(filepath), "Minor/xlsx", System.IO.Path.GetFileName(filepath));

        }


    }
}
