﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StockTakeModuleWebApp.Models;
using StockTakeModuleWebApp.Models.Report_Models;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.CodeAnalysis;
using StockTakeModuleWebApp.Models.AssetType_Model;
using StockTakeModuleWebApp.Models.Products;
using Location = StockTakeModuleWebApp.Models.Report_Models.Location;
using System.Globalization;
using System.Net;
using Microsoft.AspNetCore.Mvc.Filters;
using StockTakeModuleWebApp.Models.AuthenModel;
using StockTakeModuleWebApp.Services;
using System.Net.Http;
using System.Web;
using Nancy.Responses;
using StockTakeModuleWebApp.Models.Assets;
using StockTakeModuleWebApp.Models.Location;
using StockTakeModuleWebApp.Models.ViewModel;

namespace StockTakeModuleWebApp.Controllers
{
    public class ReportController : Controller
    {
        private readonly IStocktakeService<User> _reportService;
        public ReportController(IStocktakeService<User> reportService)
        {
            _reportService = reportService;
        }

        public List<String> locationNames = new List<string>();

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }

        string Baseurl = "https://africanbank.freshservice.com";

        public async Task<ActionResult> Report()
        {
            var username = HttpContext.Session.GetString("username");

            var user = await _reportService.FindByUsernameAsync(username);

            if (user != null)
            {
                if (user.isLoggedIn == false)
                {
                    HttpContext.Session.Clear();

                }
                else
                    user.isLoggedIn = true;

                if (HttpContext.Session.GetString("username") == null)
                {
                    return RedirectToAction("Login", "Login");
                }
            }
            else
                return RedirectToAction("Login", "Login");

            using(var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Request
                HttpRequestMessage LocRequest = new HttpRequestMessage(HttpMethod.Get, "https://itamuat.africanbank.net:8443/Locations");
                LocRequest.Content = new StringContent(JsonConvert.SerializeObject(""));
                LocRequest.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                //sending the request and getting response
                HttpResponseMessage locaResults = await client.SendAsync(LocRequest);

                if (locaResults.IsSuccessStatusCode)
                {

                    var LocResponse = locaResults.Content.ReadAsStringAsync().Result;

                    var LocResultsObj = JsonConvert.DeserializeObject<Locations[]>(LocResponse);

                    if(LocResultsObj != null)
                    {
                        foreach(var location in LocResultsObj)
                        {
                            locationNames.Add(location.name);
                            ViewBag.locations = JsonConvert.SerializeObject(locationNames);

                        }
                    }
                    else
                    {

                        return View("Error", "Error");
                    }

                    HttpContext.Session.SetString("locationNames", JsonConvert.SerializeObject(locationNames));

                    var username2 = TempData["userDetails"];
                    ViewBag.username = username2;
                    ViewBag.isITAsset = true;

                    ViewBag.locations = HttpContext.Session.GetString("locationNames");

                }
            }
            TempData["username"] = HttpContext.Session.GetString("username");
            return View();
        }

        public async Task<ActionResult> LoadReport()
        {
            var username = HttpContext.Session.GetString("username");

            var user = await _reportService.FindByUsernameAsync(username);

            if (user != null)
            {
                if (user.isLoggedIn == false)
                {
                    HttpContext.Session.Clear();

                }
                else
                    user.isLoggedIn = true;

                if (HttpContext.Session.GetString("username") == null)
                {
                    return RedirectToAction("Login", "Login");
                }
            }
            else
                return RedirectToAction("Login", "Login");

            var locations = HttpContext.Session.GetString("locationNames");

            if (HttpContext.Session.GetString("locationNames") == null)
            {


                //create a proxy object
                var proxy = new WebProxy
                {
                    Address = new Uri($"http://{"Midwsa.africanbank.net"}:{"3128"}"),
                    BypassProxyOnLocal = false,
                    UseDefaultCredentials = false,

                    // *** These creds are given to the proxy server, not the web server ***
                    Credentials = new NetworkCredential(
                        userName: "",
                        password: "")
                };

                //Create a client handler which uses that proxy
                var httpClientHandler = new HttpClientHandler
                {
                    Proxy = proxy,
                };



                // Finally, create the HTTP client object
                var client = new HttpClient(handler: httpClientHandler, disposeHandler: true);


                client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders
                          .Accept
                          .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    // Adding API Key
                    var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                    var URL = "https://africanbank.freshservice.com/api/v2/locations?" + "per_page=100&page=1";

                    int pageNumber = 2;

                    do
                    {

                        //Request
                        HttpRequestMessage requestLoc = new HttpRequestMessage(HttpMethod.Get, URL);

                        //adding hearders and content to the request
                        requestLoc.Content = new StringContent(JsonConvert.SerializeObject(""));
                        requestLoc.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");


                        //sending the request and getting response
                        HttpResponseMessage LocResults = await client.SendAsync(requestLoc);

                        if (LocResults.IsSuccessStatusCode)
                        {

                            //getting results from the RestApi (JSON formart)
                            var LocResponse = LocResults.Content.ReadAsStringAsync().Result;
                            var loctResultsObj = JsonConvert.DeserializeObject<LocationResultsObJ>(LocResponse);


                            if (loctResultsObj != null)
                            {

                                if (loctResultsObj.locations.Length > 0 && pageNumber <= 40)
                                {

                                    if (loctResultsObj.locations.Any())
                                    {
                                        foreach (var loc in loctResultsObj.locations)
                                        {
                                            locationNames.Add(loc.name);
                                            ViewBag.locations = JsonConvert.SerializeObject(locationNames);
                                        }

                                    }


                                    URL = "https://africanbank.freshservice.com/api/v2/locations?" + "per_page=100&page=" + pageNumber;
                                    pageNumber++;

                                }
                                else
                                {
                                    //End loop if the asset list is empty
                                    URL = string.Empty;
                                }




                            }

                        }
                        else
                        {
                            //End loop if we get an error
                            URL = string.Empty;
                            return View("Report", "Report");
                        }

                    } while (!string.IsNullOrEmpty(URL));


                    HttpContext.Session.SetString("locationNames", JsonConvert.SerializeObject(locationNames));

                    var username2 = TempData["userDetails"];
                    ViewBag.username = username2;
                    ViewBag.isITAsset = true;

                    ViewBag.locations = HttpContext.Session.GetString("locationNames");
                

                         

            }
            else
            {

                var username2 = TempData["userDetails"];
                ViewBag.username = username2;
                ViewBag.isITAsset = true;

                ViewBag.locations = HttpContext.Session.GetString("locationNames");

            }


            TempData["username"] = HttpContext.Session.GetString("username");
            return View();

        }

        public async Task<ActionResult> SingleSearch(string assetname, string tagn, string serialn)
        {

            try{


                ViewBag.assetname = assetname;
                ViewBag.tagn = tagn;
                ViewBag.serialn = serialn;
                ViewBag.isITAsset = true;


                //create a proxy object
                var proxy = new WebProxy
                {
                    Address = new Uri($"http://{"Midwsa.africanbank.net"}:{"3128"}"),
                    BypassProxyOnLocal = false,
                    UseDefaultCredentials = false,

                    // *** These creds are given to the proxy server, not the web server ***
                    Credentials = new NetworkCredential(
                        userName: "",
                        password: "")
                };

                //Create a client handler which uses that proxy
                var httpClientHandler = new HttpClientHandler
                {
                    Proxy = proxy,
                };

                // Finally, create the HTTP client object
                var client = new HttpClient(handler: httpClientHandler, disposeHandler: true);

                client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders
                        .Accept
                        .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    var URL = "";

                    if(assetname != null)
                    {
                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&search=\"name%3A%27{assetname}%27\"";
                    }
                    else if(tagn != null)
                    {
                        URL= "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&search=\"asset_tag:%27{tagn}%27\"";
                    }
                    else if(serialn != null)
                    {
                        URL= "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&search=\"serial_number%3A%27{serialn}%27\"";
                    }
                
                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, URL);


                    // Adding API Key
                    var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                    //adding hearders and content to the request

                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    //sending the request and getting response

                    HttpResponseMessage SingleRes = await client.SendAsync(request);

                    if (SingleRes.IsSuccessStatusCode)
                    {

                        //getting results from the RestApi (JSON formart)
                        var response = SingleRes.Content.ReadAsStringAsync().Result;

                        var assetStringObj = JsonConvert.DeserializeObject<AssetResultsData>(response);

                        List<Asset> assetDataList = new List<Asset>();

                        foreach (var assetResult in assetStringObj.assets)
                        {
                            Asset assetData = new Asset();

                            asset_type type = new asset_type();
                            Product product = new Product();
                            Department department = new Department();
                            Location location = new Location();

                            //Get Asset Types

                            //Request
                            HttpRequestMessage requestAssetTypes = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/asset_types/" + assetResult.asset_type_id);

                            //adding hearders and content to the request
                            requestAssetTypes.Content = new StringContent(JsonConvert.SerializeObject(""));
                            requestAssetTypes.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                            //sending the request and getting response
                            HttpResponseMessage assetTypesResults = await client.SendAsync(requestAssetTypes);

                            if (assetTypesResults.IsSuccessStatusCode)
                            {

                                //getting results from the RestApi (JSON formart)
                                var AssetTypesResponse = assetTypesResults.Content.ReadAsStringAsync().Result;

                                var typeObject = JsonConvert.DeserializeObject<AssetTypeResultsData>(AssetTypesResponse);

                                if (typeObject != null)
                                {
                                    type = typeObject.asset_type;
                                }


                            }

                            //End of asset types

                            //Get Products

                            //Request
                            HttpRequestMessage requestProduct = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/products/" + assetResult.type_fields.product_50000156930);

                            //adding hearders and content to the request
                            requestProduct.Content = new StringContent(JsonConvert.SerializeObject(""));
                            requestProduct.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                            //sending the request and getting response
                            HttpResponseMessage productResults = await client.SendAsync(requestProduct);

                            if (productResults.IsSuccessStatusCode)
                            {

                                //getting results from the RestApi (JSON formart)
                                var ProductResponse = productResults.Content.ReadAsStringAsync().Result;

                                var productObject = JsonConvert.DeserializeObject<ProductResultsData>(ProductResponse);

                                if (productObject != null)
                                {
                                    product = productObject.product;
                                }


                            }

                            //End of products

                            //Get Dept

                            //Request
                            HttpRequestMessage requestDeptObj = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/departments/" + assetResult.department_id);

                            //adding hearders and content to the request
                            requestDeptObj.Content = new StringContent(JsonConvert.SerializeObject(""));
                            requestDeptObj.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                            //sending the request and getting response
                            HttpResponseMessage deptObjResults = await client.SendAsync(requestDeptObj);

                            if (deptObjResults.IsSuccessStatusCode)
                            {

                                //getting results from the RestApi (JSON formart)
                                var DeptObjResponse = deptObjResults.Content.ReadAsStringAsync().Result;

                                var DeptObject = JsonConvert.DeserializeObject<DepartmentResults>(DeptObjResponse);

                                if (DeptObject != null)
                                {
                                    department = DeptObject.department;
                                }


                            }

                            //End Dept

                            //Get Loc

                            //Request
                            HttpRequestMessage requestLocationObject = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/locations/" + assetResult.location_id);

                            //adding hearders and content to the request
                            requestLocationObject.Content = new StringContent(JsonConvert.SerializeObject(""));
                            requestLocationObject.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                            //sending the request and getting response
                            HttpResponseMessage LocObjResults = await client.SendAsync(requestLocationObject);

                            if (LocObjResults.IsSuccessStatusCode)
                            {

                                //getting results from the RestApi (JSON formart)
                                var LocationObjResponse = LocObjResults.Content.ReadAsStringAsync().Result;

                                var LocObject = JsonConvert.DeserializeObject<LocationResults>(LocationObjResponse);

                                if (LocObject != null)
                                {
                                    location = LocObject.location;
                                }


                            }

                            //End Location
                            var auditdateString = assetResult.type_fields.last_audit_date_50000156930;
                            var stocktakedateString = assetResult.type_fields.stock_take_date_50000156930;
                            string separator = "T";
                            string[] auditdatelist;
                            string[] stoketakedatelist;


                            assetData.AssetName = assetResult.name;
                            assetData.AssetType = type.name;
                            assetData.SerialNumber = assetResult.type_fields.serial_number_50000156930;
                            assetData.UsedBy = assetResult.type_fields.last_login_by_50000156935;
                            assetData.AssetState = assetResult.type_fields.asset_state_50000156930;
                            if (auditdateString != null)
                            {
                                auditdatelist = auditdateString.Split(separator);
                                String auditDate = auditdatelist[0];
                                DateTime date1 = DateTime.Parse(auditDate);
                                assetData.LastAuditDate = date1.ToString("yyyy-MM-dd");

                            }
                            else
                                assetData.LastAuditDate = assetResult.type_fields.last_audit_date_50000156930;

                            if (stocktakedateString != null)
                            {
                                stoketakedatelist = stocktakedateString.Split(separator);
                                String stocktakeDate = stoketakedatelist[0];
                                DateTime date2 = DateTime.Parse(stocktakeDate);
                                assetData.StocktakeDate = date2.ToString("yyyy-MM-dd");
                            }
                            else
                                assetData.StocktakeDate = assetResult.type_fields.stock_take_date_50000156930;

                            assetData.AssetTag = assetResult.asset_tag;
                            assetData.LastLoginBy = assetResult.type_fields.last_login_by_50000156935;

                            if(location != null)
                            {
                                assetData.LocationName = location.name;
                            }

                            if (product != null)
                            {
                                assetData.ProductName = product.name;
                            }
                            if (department != null)
                            {
                                assetData.DepartmentName = department.name;
                            }

                            assetDataList.Add(assetData);


                        }

                        ReportViewModel reportViewModel = new ReportViewModel();
                        reportViewModel.AssetList = assetDataList.ToArray();

                        if (assetStringObj != null)
                        {

                            return View("Report", reportViewModel);

                        }
                        else
                        {
                            return View("Report", "Report");
                        }

                    }
                    else
                    {
                        return View("Report", "Report");
                    }



               
            
            }catch(Exception e){

                return Redirect("Error");

            }

        }


        public async Task<ActionResult> LocationSearch(string asset, string code, string location)
        {

            ViewBag.asset = asset;
            ViewBag.code = code;
            ViewBag.location = location;

            bool isITAsset = false;
            var nonAssetTypeId = "";

            if (!string.IsNullOrEmpty(asset) && !string.IsNullOrWhiteSpace(asset))
            {
                if (asset.ToString().Equals("non-it"))
                {
                    isITAsset = false;
                    nonAssetTypeId = "50000243575";
                    ViewBag.isITAsset = false;
                }
                else
                {
                    isITAsset = true;
                    ViewBag.isITAsset = true;
                }
            }

            //create a proxy object
            var proxy = new WebProxy
            {
                Address = new Uri($"http://{"Midwsa.africanbank.net"}:{"3128"}"),
                BypassProxyOnLocal = false,
                UseDefaultCredentials = false,

                // *** These creds are given to the proxy server, not the web server ***
                Credentials = new NetworkCredential(
                    userName: "",
                    password: "")
            };

            //Create a client handler which uses that proxy
            var httpClientHandler = new HttpClientHandler
            {
                Proxy = proxy,
            };

            // Finally, create the HTTP client object
            var client = new HttpClient(handler: httpClientHandler, disposeHandler: true);



            client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders
                    .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // Adding API Key
                var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                //get dept Id Start
                var deptId = "";

                //Request
                HttpRequestMessage requestDept = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/departments?" + $"query=\"name:%27{code}%27\"");

                //adding hearders and content to the request
                requestDept.Content = new StringContent(JsonConvert.SerializeObject(""));
                requestDept.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                //sending the request and getting response
                HttpResponseMessage Deptresults = await client.SendAsync(requestDept);

                if (Deptresults.IsSuccessStatusCode)
                {

                    //getting results from the RestApi (JSON formart)
                    var Deptresponse = Deptresults.Content.ReadAsStringAsync().Result;

                    var deptResultsObj = JsonConvert.DeserializeObject<DepartmentResultsObj>(Deptresponse);

                    if (deptResultsObj != null)
                    {
                        foreach (var dept in deptResultsObj.Departments)
                        {

                            deptId = dept.id;

                        }


                    }
                }

                //End Dept Id

                //Start Location ID

                var locId = "";

                //Request
                HttpRequestMessage requestLoc = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/locations?" + $"query=\"name%3A%27{location}%27\"");

                //adding hearders and content to the request
                requestLoc.Content = new StringContent(JsonConvert.SerializeObject(""));
                requestLoc.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                //sending the request and getting response
                HttpResponseMessage LocResults = await client.SendAsync(requestLoc);

                if (LocResults.IsSuccessStatusCode)
                {

                    //getting results from the RestApi (JSON formart)
                    var LocResponse = LocResults.Content.ReadAsStringAsync().Result;

                    var loctResultsObj = JsonConvert.DeserializeObject<LocationResultsObJ>(LocResponse);

                    if (loctResultsObj != null)
                    {


                        foreach (var loc in loctResultsObj.locations)
                        {
                            locId = loc.id;
                        }

                    }
                }


                //Getting all assert 
                var URL = "";
                var assetList = new List<Assets>();
                var ITAssetsList = new List<Assets>();
                var NonITAssetsList = new List<Assets>();
                List<AssetData> assetDataList = new List<AssetData>();


                if (!isITAsset)
                {

                    ViewBag.isITAsset = false;

                    if (!string.IsNullOrEmpty(locId) && !string.IsNullOrWhiteSpace(locId))
                    {
                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"location_id:{locId} AND asset_type_id:{nonAssetTypeId}\"&page={1}";
                    }
                    else if (!string.IsNullOrEmpty(deptId) && !string.IsNullOrWhiteSpace(deptId))
                    {
                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"department_id:{deptId} AND asset_type_id:{nonAssetTypeId}\"&page={1}";
                    }

                }
                else
                {
                    ViewBag.isITAsset = true;

                    if (!string.IsNullOrEmpty(locId) && !string.IsNullOrWhiteSpace(locId))
                    {
                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"(asset_type_id:50000231330 OR asset_type_id:50000156951 OR asset_type_id:50000156944 OR asset_type_id:50000156943 OR asset_type_id:50000156952 OR asset_type_id:50000156940) AND location_id:{locId}\"&page={1}";
                    }
                    else if (!string.IsNullOrEmpty(deptId) && !string.IsNullOrWhiteSpace(deptId))
                    {
                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"(asset_type_id:50000231330 OR asset_type_id:50000156951 OR asset_type_id:50000156944 OR asset_type_id:50000156943 OR asset_type_id:50000156952 OR asset_type_id:50000156940) AND department_id:{deptId}\"&page={1}";
                    }
                }

                int pageNumber = 2;


                do
                {

                    var assetStringObj = new AssetResultsData();

                    //Request
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, URL);

                    //adding hearders and content to the request
                    request.Content = new StringContent(JsonConvert.SerializeObject(""));
                    request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    //sending the request and getting response
                    HttpResponseMessage LocationRes = await client.SendAsync(request);

                    if (LocationRes.IsSuccessStatusCode)
                    {

                        var response = LocationRes.Content.ReadAsStringAsync().Result;
                        assetStringObj = JsonConvert.DeserializeObject<AssetResultsData>(response);

                        if (assetStringObj != null)
                        {

                            if (assetStringObj.assets.Length > 0 && pageNumber <= 40)
                            {

                                if (assetStringObj.assets.Any())
                                {
                                    assetList.AddRange(assetStringObj.assets.ToList());

                                }


                                if (!isITAsset)
                                {

                                    if (!string.IsNullOrEmpty(locId) && !string.IsNullOrWhiteSpace(locId))
                                    {
                                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"location_id:{locId} AND asset_type_id:{nonAssetTypeId}\"&page={pageNumber}";
                                    }
                                    else if (!string.IsNullOrEmpty(deptId) && !string.IsNullOrWhiteSpace(deptId))
                                    {
                                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"department_id:{deptId} AND asset_type_id:{nonAssetTypeId}\"&page={pageNumber}";
                                    }

                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(locId) && !string.IsNullOrWhiteSpace(locId))
                                    {
                                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"(asset_type_id:50000231330 OR asset_type_id:50000156951 OR asset_type_id:50000156944 OR asset_type_id:50000156943 OR asset_type_id:50000156952 OR asset_type_id:50000156940) AND location_id:{locId}\"&page={pageNumber}";
                                    }
                                    else if (!string.IsNullOrEmpty(deptId) && !string.IsNullOrWhiteSpace(deptId))
                                    {
                                        URL = "https://africanbank.freshservice.com/api/v2/assets?" + $"include=type_fields&filter=\"(asset_type_id:50000231330 OR asset_type_id:50000156951 OR asset_type_id:50000156944 OR asset_type_id:50000156943 OR asset_type_id:50000156952 OR asset_type_id:50000156940) AND department_id:{deptId}\"&page={pageNumber}";
                                    }
                                }


                                pageNumber++;

                            }
                            else
                            {
                                //End loop if the asset list is empty
                                URL = string.Empty;
                            }




                        }

                    }
                    else
                    {
                        //End loop if we get an error
                        URL = string.Empty;
                        return View("Report", "Report");
                    }

                } while (!string.IsNullOrEmpty(URL));


                foreach (var assetResult in assetList)
                {
                    AssetData assetData = new AssetData();

                    asset_type type = new asset_type();
                    Product product = new Product();
                    Department department = new Department();
                    Location locationObject = new Location();

                    //Get Asset Types

                    //Request
                    HttpRequestMessage requestAssetTypes = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/asset_types/" + assetResult.asset_type_id);

                    //adding hearders and content to the request
                    requestLoc.Content = new StringContent(JsonConvert.SerializeObject(""));
                    requestLoc.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    //sending the request and getting response
                    HttpResponseMessage assetTypesResults = await client.SendAsync(requestAssetTypes);

                    if (assetTypesResults.IsSuccessStatusCode)
                    {

                        //getting results from the RestApi (JSON formart)
                        var AssetTypesResponse = assetTypesResults.Content.ReadAsStringAsync().Result;

                        var typeObject = JsonConvert.DeserializeObject<AssetTypeResultsData>(AssetTypesResponse);

                        if (typeObject != null)
                        {
                            type = typeObject.asset_type;
                        }


                    }

                    //End of asset types

                    //Get Dept

                    //Request
                    HttpRequestMessage requestDeptObj = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/departments/" + assetResult.department_id);

                    //adding hearders and content to the request
                    requestDeptObj.Content = new StringContent(JsonConvert.SerializeObject(""));
                    requestDeptObj.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    //sending the request and getting response
                    HttpResponseMessage deptObjResults = await client.SendAsync(requestDeptObj);

                    if (deptObjResults.IsSuccessStatusCode)
                    {

                        //getting results from the RestApi (JSON formart)
                        var DeptObjResponse = deptObjResults.Content.ReadAsStringAsync().Result;

                        var DeptObject = JsonConvert.DeserializeObject<DepartmentResults>(DeptObjResponse);

                        if (DeptObject != null)
                        {
                            department = DeptObject.department;
                        }


                    }

                    //End Dept

                    //Get Loc

                    //Request
                    HttpRequestMessage requestLocationObject = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/locations/" + assetResult.location_id);

                    //adding hearders and content to the request
                    requestLocationObject.Content = new StringContent(JsonConvert.SerializeObject(""));
                    requestLocationObject.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                    //sending the request and getting response
                    HttpResponseMessage LocObjResults = await client.SendAsync(requestLocationObject);

                    if (LocObjResults.IsSuccessStatusCode)
                    {

                        //getting results from the RestApi (JSON formart)
                        var LocationObjResponse = LocObjResults.Content.ReadAsStringAsync().Result;

                        var LocObject = JsonConvert.DeserializeObject<LocationResults>(LocationObjResponse);

                        if (LocObject != null)
                        {
                            locationObject = LocObject.location;
                        }


                    }

                    //End Location

                    if (!isITAsset)
                    {

                        //Get Products

                        //Request
                        HttpRequestMessage requestProduct = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/products/" + assetResult.type_fields.product_50000156931);

                        //adding hearders and content to the request
                        requestProduct.Content = new StringContent(JsonConvert.SerializeObject(""));
                        requestProduct.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        //sending the request and getting response
                        HttpResponseMessage productResults = await client.SendAsync(requestProduct);

                        if (productResults.IsSuccessStatusCode)
                        {

                            //getting results from the RestApi (JSON formart)
                            var ProductResponse = productResults.Content.ReadAsStringAsync().Result;

                            var productObject = JsonConvert.DeserializeObject<ProductResultsData>(ProductResponse);

                            if (productObject != null)
                            {
                                product = productObject.product;
                            }


                        }

                        //End of products

                        var auditdateString = assetResult.type_fields.last_audit_date_50000156930;
                        var stocktakedateString = assetResult.type_fields.stock_take_date_50000156931;
                        string separator = "T";
                        string[] auditdatelist;
                        string[] stoketakedatelist;

                        assetData.Name = assetResult.name;
                        assetData.AssetType = type.name;
                        assetData.UsedBy = assetResult.type_fields.last_login_by_50000156935;
                        assetData.AssetTag = assetResult.asset_tag;
                        assetData.quantity = assetResult.type_fields.quantity_50000156931;
                        assetData.state = assetResult.type_fields.state_50000156931;
                        if (stocktakedateString != null)
                        {
                            stoketakedatelist = stocktakedateString.Split(separator);
                            String stocktakeDate = stoketakedatelist[0];
                            DateTime date2 = DateTime.Parse(stocktakeDate);
                            assetData.StocktakeDate = date2.ToString("yyyy-MM-dd");
                        }
                        else
                            assetData.StocktakeDate = assetResult.type_fields.stock_take_date_50000156931;

                        if (product != null)
                        {
                            assetData.Product = product.name;
                        }
                        if (department != null)
                        {
                            assetData.Department = department.name;
                        }

                        if (locationObject != null)
                        {
                            assetData.Location = locationObject.name;
                        }
                    }
                    else
                    {

                        //Get Products

                        //Request
                        HttpRequestMessage requestProduct = new HttpRequestMessage(HttpMethod.Get, "https://africanbank.freshservice.com/api/v2/products/" + assetResult.type_fields.product_50000156930);

                        //adding hearders and content to the request
                        requestProduct.Content = new StringContent(JsonConvert.SerializeObject(""));
                        requestProduct.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        //sending the request and getting response
                        HttpResponseMessage productResults = await client.SendAsync(requestProduct);

                        if (productResults.IsSuccessStatusCode)
                        {

                            //getting results from the RestApi (JSON formart)
                            var ProductResponse = productResults.Content.ReadAsStringAsync().Result;

                            var productObject = JsonConvert.DeserializeObject<ProductResultsData>(ProductResponse);

                            if (productObject != null)
                            {
                                product = productObject.product;
                            }


                        }

                        //End of products


                        var auditdateString = assetResult.type_fields.last_audit_date_50000156930;
                        var stocktakedateString = assetResult.type_fields.stock_take_date_50000156930;
                        string separator = "T";
                        string[] auditdatelist;
                        string[] stoketakedatelist;

                        assetData.Name = assetResult.name;
                        assetData.AssetType = type.name;
                        assetData.SerianNumber = assetResult.type_fields.serial_number_50000156930;
                        assetData.UsedBy = assetResult.type_fields.last_login_by_50000156935;
                        assetData.AssetState = assetResult.type_fields.asset_state_50000156930;
                        assetData.AssetTag = assetResult.asset_tag;
                        assetData.LastLoginby = assetResult.type_fields.last_login_by_50000156935;
                        assetData.quantity = assetResult.type_fields.quantity_50000156931;
                        assetData.state = assetResult.type_fields.state_50000156931;

                        if (auditdateString != null)
                        {
                            auditdatelist = auditdateString.Split(separator);
                            String auditDate = auditdatelist[0];
                            DateTime date1 = DateTime.Parse(auditDate);
                            assetData.LastAuditDate = date1.ToString("yyyy-MM-dd");

                        }
                        else
                            assetData.LastAuditDate = assetResult.type_fields.last_audit_date_50000156930;

                        if (stocktakedateString != null)
                        {
                            stoketakedatelist = stocktakedateString.Split(separator);
                            String stocktakeDate = stoketakedatelist[0];
                            DateTime date2 = DateTime.Parse(stocktakeDate);
                            assetData.StocktakeDate = date2.ToString("yyyy-MM-dd");
                        }
                        else
                            assetData.StocktakeDate = assetResult.type_fields.stock_take_date_50000156930;

                        if (product != null)
                        {
                            assetData.Product = product.name;
                        }
                        if (department != null)
                        {
                            assetData.Department = department.name;
                        }

                        if (locationObject != null)
                        {
                            assetData.Location = locationObject.name;
                        }

                    }

                    assetDataList.Add(assetData);

                }


                if (assetDataList != null)
                {
                    return View("Report", assetDataList);
                }
                else
                {
                    return View("Report", "Report");
                }
            }

        public async Task<ActionResult> MultipleSearch(string asset, string location, string department, string costCode)
        {
            using (var client = new HttpClient())
            {

                bool isITAsset = true;
                if(asset == "IT")
                {
                    isITAsset = true;
                    ViewBag.isITAsset = true;
                }
                else
                {
                    isITAsset = false;
                    ViewBag.isITAsset = false;
                }
                    

                var encodedLocationURL = $"https://itamuat.africanbank.net:8443/AssetByLocation?location={HttpUtility.UrlEncode(location)}&assetType={asset}";
                var encodedDepartmentURL = $"https://itamuat.africanbank.net:8443/AssetByDepartment?department={HttpUtility.UrlEncode(department)}&assetType={asset}";
                var encodedCostCodeURL = $"https://itamuat.africanbank.net:8443/AssetByCostCode?costCode={HttpUtility.UrlEncode(costCode)}&assetType={asset}";
                string encodedURL;

                if (location != null)
                    encodedURL = encodedLocationURL;
                else if (department != null)
                    encodedURL = encodedDepartmentURL;
                else
                    encodedURL = encodedCostCodeURL;

                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders
                      .Accept
                      .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Request
                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, encodedURL);
                request.Content = new StringContent(JsonConvert.SerializeObject(""));
                request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                //sending the request and getting response
                HttpResponseMessage reqResults = await client.SendAsync(request);

                if(reqResults.IsSuccessStatusCode)
                {
                    var reqResponse = reqResults.Content.ReadAsStringAsync().Result;

                    var reqResultsObj = JsonConvert.DeserializeObject<Asset[]>(reqResponse);

                    var assestList = new List<Asset>();
                    var getAssets = new Asset();

                    if(reqResultsObj != null)
                    {
                        if (isITAsset)
                        {
                            foreach (var assetsResulto in reqResultsObj)
                            {
                                var auditdateString = assetsResulto.LastAuditDate;
                                var stocktakedateString = assetsResulto.StocktakeDate;
                                string separator = "T";
                                string[] auditdatelist;
                                string[] stoketakedatelist;

                                getAssets = new Asset();

                                getAssets.AssetName = assetsResulto.AssetName;
                                getAssets.AssetTag = assetsResulto.AssetTag;
                                getAssets.AssetType = assetsResulto.AssetType;
                                getAssets.AssetState = assetsResulto.AssetState;
                                getAssets.DepartmentName = assetsResulto.DepartmentName;
                                getAssets.id = assetsResulto.id;
                                getAssets.LocationName = assetsResulto.LocationName;
                                getAssets.CostCode = assetsResulto.CostCode;
                                getAssets.ProductName = assetsResulto.ProductName;
                                if (auditdateString != null)
                                {
                                    auditdatelist = auditdateString.Split(separator);
                                    String auditDate = auditdatelist[0];
                                    DateTime date1 = DateTime.Parse(auditDate);
                                    getAssets.LastAuditDate = date1.ToString("yyyy-MM-dd");
                                }
                                else
                                    getAssets.LastAuditDate = assetsResulto.LastAuditDate;
                                getAssets.LastLoginBy = assetsResulto.LastLoginBy;
                                getAssets.SerialNumber = assetsResulto.SerialNumber;
                                getAssets.UsedBy = assetsResulto.UsedBy;
                                if (stocktakedateString != null)
                                {
                                    stoketakedatelist = stocktakedateString.Split(separator);
                                    String stocktakeDate = stoketakedatelist[0];
                                    DateTime date2 = DateTime.Parse(stocktakeDate);
                                    getAssets.StocktakeDate = date2.ToString("yyyy-MM-dd");
                                }
                                else
                                    getAssets.StocktakeDate = assetsResulto.StocktakeDate;

                                assestList.Add(getAssets);
                            }

                            ReportViewModel reportViewModel = new ReportViewModel();
                            reportViewModel.AssetList = assestList.ToArray();

                            if (assestList != null)
                            {
                                return View("Report", reportViewModel);
                            }
                            else
                            {
                                return View("Report", "Report");
                            }
                        }
                        else
                        {
                            foreach (var assetsResulto in reqResultsObj)
                            {
                                var auditdateString = assetsResulto.LastAuditDate;
                                var stocktakedateString = assetsResulto.StocktakeDate;
                                string separator = "T";
                                string[] auditdatelist;
                                string[] stoketakedatelist;


                                getAssets = new Asset();

                                getAssets.AssetName = assetsResulto.AssetName;
                                getAssets.AssetTag = assetsResulto.AssetTag;
                                getAssets.AssetType = assetsResulto.AssetType;
                                getAssets.AssetState = assetsResulto.AssetState;
                                getAssets.DepartmentName = assetsResulto.DepartmentName;
                                getAssets.id = assetsResulto.id;
                                getAssets.LocationName = assetsResulto.LocationName;
                                getAssets.ProductName = assetsResulto.ProductName;
                                if (auditdateString != null)
                                {
                                    auditdatelist = auditdateString.Split(separator);
                                    String auditDate = auditdatelist[0];
                                    DateTime date1 = DateTime.Parse(auditDate);
                                    getAssets.LastAuditDate = date1.ToString("yyyy-MM-dd");
                                }
                                else
                                    getAssets.LastAuditDate = assetsResulto.LastAuditDate;
                                getAssets.LastLoginBy = assetsResulto.LastLoginBy;
                                getAssets.Quantity = assetsResulto.Quantity;
                                getAssets.SerialNumber = assetsResulto.SerialNumber;
                                getAssets.UsedBy = assetsResulto.UsedBy;
                                if (stocktakedateString != null)
                                {
                                    stoketakedatelist = stocktakedateString.Split(separator);
                                    String stocktakeDate = stoketakedatelist[0];
                                    DateTime date2 = DateTime.Parse(stocktakeDate);
                                    getAssets.StocktakeDate = date2.ToString("yyyy-MM-dd");
                                }
                                else
                                    getAssets.StocktakeDate = assetsResulto.StocktakeDate;

                                assestList.Add(getAssets);
                            }
                            
                            ReportViewModel reportViewModel = new ReportViewModel();
                            reportViewModel.AssetList = assestList.ToArray();

                            if (assestList != null)
                            {
                                return View("Report", reportViewModel);
                            }
                            else
                            {
                                return View("Error", "Error");
                            }
                        }
                        
                    }



                }

                return View("Report", "Report");
            }
        }

    }
}
