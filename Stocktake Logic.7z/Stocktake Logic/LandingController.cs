﻿using Microsoft.AspNetCore.Mvc;
using StockTakeModuleWebApp.Models.AuthenModel;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using StockTakeModuleWebApp.Models.Report_Models;
using Newtonsoft.Json;
using StockTakeModuleWebApp.Services;

namespace StockTakeModuleWebApp.Controllers
{
    public class LandingController : Controller
    {
        private readonly IStocktakeService<User> _landingService;

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (HttpContext.Session.GetString("username") == null)
            {
                HttpContext.Response.Redirect("/");
            }

            base.OnActionExecuting(context);

        }
        public LandingController(IStocktakeService<User> landingService)
        {
            _landingService = landingService;
        }

        public async Task<ActionResult> Landing()
        {
            var username = HttpContext.Session.GetString("username");

            var user = await _landingService.FindByUsernameAsync(username);

            if (user != null)
            {
                if (user.isLoggedIn == false)
                {
                    HttpContext.Session.Clear();

                }
                else
                    user.isLoggedIn = true;

                if (HttpContext.Session.GetString("username") == null)
                {
                    return RedirectToAction("Login", "Login");
                }
            }
            else
                return RedirectToAction("Login", "Login");


            return View();
        }
    }

}
