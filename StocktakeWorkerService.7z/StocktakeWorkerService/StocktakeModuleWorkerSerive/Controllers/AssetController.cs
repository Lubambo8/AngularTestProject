﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StocktakeModuleWorkerSerive.Models.Assets;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class AssetController : Controller
    {
        private readonly ILogger<AssetController> _logger;

        public AssetController(ILogger<AssetController> logger)
        {
            _logger = logger;
        }


        [HttpGet(Name = "GetAssets")]
        public async Task<HttpStatusCode> GetAssets()
        {
            string BaseURL = "https://africanbank.freshservice.com";
            
            using (var client = new HttpClient())
            {
                int pageNumber = 1;
                var maxPagelength = false;
                client.BaseAddress = new Uri(BaseURL);
                client.DefaultRequestHeaders
                    .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                

                try
                {
                    var URL = "";
                    List<Assets> assetDataList = new List<Assets>();
                    do
                    {
                        URL = $"https://africanbank.freshservice.com/api/v2/assets?include=type_fields&per_page=100&page={pageNumber}";

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get,URL);

                        var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                        request.Content = new StringContent(JsonConvert.SerializeObject(""));
                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage Res = await client.SendAsync(request);

                        

                        if (Res.IsSuccessStatusCode)
                        {
                            var response = Res.Content.ReadAsStringAsync().Result;

                            var assetStringObj = JsonConvert.DeserializeObject<AssetResultsData>(response);


                            if(assetStringObj.assets.Length > 0)
                            {
                                foreach (var assetResult in assetStringObj.assets)
                                {
                                    Assets assetData = new Assets();

                                    assetData.id = assetResult.id;
                                    assetData.display_id = assetResult.display_id;
                                    assetData.name = assetResult.name;
                                    assetData.description = assetResult.description;
                                    assetData.asset_type_id = assetResult.asset_type_id;
                                    assetData.impact = assetResult.impact;
                                    assetData.author_type = assetResult.author_type;
                                    assetData.usage_type = assetResult.usage_type;
                                    assetData.asset_tag = assetResult.asset_tag;
                                    assetData.user_id = assetResult.user_id;
                                    assetData.department_id = assetResult.department_id;
                                    assetData.location_id = assetResult.location_id;
                                    assetData.agent_id = assetResult.agent_id;
                                    assetData.group_id = assetResult.group_id;
                                    assetData.assigned_on = assetResult.assigned_on;
                                    assetData.created_at = assetResult.created_at;
                                    assetData.updated_at = assetResult.updated_at;
                                    assetData.type_fields = assetResult.type_fields;
                                    if (assetData.type_fields != null && assetResult.type_fields != null)
                                    {
                                        assetData.type_fields.product_50000156930 = assetResult.type_fields.product_50000156930;
                                        assetData.type_fields.vendor_50000156930 = assetResult.type_fields.vendor_50000156930;
                                        assetData.type_fields.virtual_host_50000156930 = assetResult.type_fields.virtual_host_50000156930;
                                        assetData.type_fields.cost_50000156930 = assetResult.type_fields.cost_50000156930;
                                        assetData.type_fields.stock_take_date_50000156930 = assetResult.type_fields.stock_take_date_50000156930;
                                        assetData.type_fields.stock_take_date_50000156931 = assetResult.type_fields.stock_take_date_50000156931;
                                        assetData.type_fields.cost_code_50000156930 = assetResult.type_fields.cost_code_50000156930;
                                        assetData.type_fields.reporting_manager_50000156930 = assetResult.type_fields.reporting_manager_50000156930;
                                        assetData.type_fields.warranty_50000156930 = assetResult.type_fields.warranty_50000156930;
                                        assetData.type_fields.acquisition_date_50000156930 = assetResult.type_fields.acquisition_date_50000156930;
                                        assetData.type_fields.warranty_expiry_date_50000156930 = assetResult.type_fields.warranty_expiry_date_50000156930;
                                        assetData.type_fields.domain_50000156930 = assetResult.type_fields.domain_50000156930;
                                        assetData.type_fields.asset_state_50000156930 = assetResult.type_fields.asset_state_50000156930;
                                        assetData.type_fields.serial_number_50000156930 = assetResult.type_fields.serial_number_50000156930;
                                        assetData.type_fields.last_audit_date_50000156930 = assetResult.type_fields.last_audit_date_50000156930;
                                        assetData.type_fields.os_50000156935 = assetResult.type_fields.os_50000156935;
                                        assetData.type_fields.os_version_50000156935 = assetResult.type_fields.os_version_50000156935;
                                        assetData.type_fields.os_service_pack_50000156935 = assetResult.type_fields.os_service_pack_50000156935;
                                        assetData.type_fields.memory_50000156935 = assetResult.type_fields.memory_50000156935;
                                        assetData.type_fields.disk_space_50000156935 = assetResult.type_fields.disk_space_50000156935;
                                        assetData.type_fields.cpu_speed_50000156935 = assetResult.type_fields.cpu_speed_50000156935;
                                        assetData.type_fields.total_cpus_50000156935 = assetResult.type_fields.total_cpus_50000156935;
                                        assetData.type_fields.cpu_core_count_50000156935 = assetResult.type_fields.cpu_core_count_50000156935;
                                        assetData.type_fields.mac_address_50000156935 = assetResult.type_fields.mac_address_50000156935;
                                        assetData.type_fields.uuid_50000156935 = assetResult.type_fields.uuid_50000156935;
                                        assetData.type_fields.hostname_50000156935 = assetResult.type_fields.hostname_50000156935;
                                        assetData.type_fields.computer_ip_address_50000156935 = assetResult.type_fields.computer_ip_address_50000156935;
                                        assetData.type_fields.depreciation_id = assetResult.type_fields.depreciation_id;
                                        assetData.type_fields.salvage = assetResult.type_fields.salvage;
                                        assetData.type_fields.state_50000156931 = assetResult.type_fields.state_50000156931;
                                        assetData.type_fields.quantity_50000156931 = assetResult.type_fields.quantity_50000156931;
                                        assetData.type_fields.product_50000156931 = assetResult.type_fields.product_50000156931;
                                    }
                                    else
                                        assetData.type_fields = null;
                                    
                                    

                                    assetDataList.Add(assetData);
                                }

                                pageNumber++;
                            }
                            else
                            {
                                maxPagelength = true;
                                //URL = string.Empty;
                            }



                            
                        }
                        else
                        {
                            return HttpStatusCode.BadRequest;
                        }

                        await Task.Delay(1000);

                    } while (maxPagelength != true);

                    var assetList = assetDataList;

                    var datTable = new DataTable();
                    datTable.Columns.Add(nameof(Assets.id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.display_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.name), typeof(string));
                    datTable.Columns.Add(nameof(Assets.description), typeof(string));
                    datTable.Columns.Add(nameof(Assets.asset_type_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.impact), typeof(string));
                    datTable.Columns.Add(nameof(Assets.author_type), typeof(string));
                    datTable.Columns.Add(nameof(Assets.usage_type), typeof(string));
                    datTable.Columns.Add(nameof(Assets.asset_tag), typeof(string));
                    datTable.Columns.Add(nameof(Assets.user_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.department_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.location_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.agent_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.group_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.assigned_on), typeof(string));
                    datTable.Columns.Add(nameof(Assets.created_at), typeof(string));
                    datTable.Columns.Add(nameof(Assets.updated_at), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.product_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.vendor_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.virtual_host_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.cost_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.stock_take_date_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.stock_take_date_50000156931), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.cost_code_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.reporting_manager_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.warranty_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.acquisition_date_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.warranty_expiry_date_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.domain_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.asset_state_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.serial_number_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.last_audit_date_50000156930), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.os_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.os_version_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.os_service_pack_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.memory_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.disk_space_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.cpu_speed_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.total_cpus_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.cpu_core_count_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.mac_address_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.uuid_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.hostname_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.computer_ip_address_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.last_login_by_50000156935), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.depreciation_id), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.salvage), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.state_50000156931), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.quantity_50000156931), typeof(string));
                    datTable.Columns.Add(nameof(Assets.type_fields.product_50000156931), typeof(string));

                    foreach (var asset in assetList)
                    {
                        datTable.Rows.Add(asset.id,
                                          asset.display_id,
                                          asset.name,
                                          asset.description,
                                          asset.asset_type_id,
                                          asset.impact,
                                          asset.author_type,
                                          asset.usage_type,
                                          asset.asset_tag,
                                          asset.user_id,
                                          asset.department_id,
                                          asset.location_id,
                                          asset.agent_id,
                                          asset.group_id,
                                          asset.assigned_on,
                                          asset.created_at,
                                          asset.updated_at,
                                          asset.type_fields.product_50000156930,
                                          asset.type_fields.vendor_50000156930,
                                          asset.type_fields.virtual_host_50000156930,
                                          asset.type_fields.cost_50000156930,
                                          asset.type_fields.stock_take_date_50000156930,
                                          asset.type_fields.stock_take_date_50000156931,
                                          asset.type_fields.cost_code_50000156930,
                                          asset.type_fields.reporting_manager_50000156930,
                                          asset.type_fields.warranty_50000156930,
                                          asset.type_fields.acquisition_date_50000156930,
                                          asset.type_fields.warranty_expiry_date_50000156930,
                                          asset.type_fields.domain_50000156930,
                                          asset.type_fields.asset_state_50000156930,
                                          asset.type_fields.serial_number_50000156930,
                                          asset.type_fields.last_audit_date_50000156930,
                                          asset.type_fields.os_50000156935,
                                          asset.type_fields.os_version_50000156935,
                                          asset.type_fields.os_service_pack_50000156935,
                                          asset.type_fields.memory_50000156935,
                                          asset.type_fields.disk_space_50000156935,
                                          asset.type_fields.cpu_speed_50000156935,
                                          asset.type_fields.total_cpus_50000156935,
                                          asset.type_fields.cpu_core_count_50000156935,
                                          asset.type_fields.mac_address_50000156935,
                                          asset.type_fields.uuid_50000156935,
                                          asset.type_fields.hostname_50000156935,
                                          asset.type_fields.computer_ip_address_50000156935,
                                          asset.type_fields.last_login_by_50000156935,
                                          asset.type_fields.depreciation_id,
                                          asset.type_fields.salvage,
                                          asset.type_fields.state_50000156931,
                                          asset.type_fields.quantity_50000156931,
                                          asset.type_fields.product_50000156931);

                    }

                    //var password = "nX1!gdm%Uf@5;9";
                    string connectionString = "SERVER=mpwopsql3\\sql01;DATABASE=StockTakeModuleDB;user id=PGFE_Dev_User;password=palKnjhvifW4kb$;MultipleActiveResultSets=true;Initial Catalog=StockTakeModuleDB;";
                    DataTable dataTable = datTable;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        
                        

                        connection.Open();

                        using (SqlTransaction transaction = connection.BeginTransaction())
                        {
                            
                            try
                            {
                                string deleteQuery = "DELETE FROM Assets";

                                using (SqlCommand command = new SqlCommand(deleteQuery, connection, transaction))
                                {
                                    command.ExecuteNonQuery();
                                }

                                // Bulk insert new data
                                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.KeepIdentity, transaction))
                                {
                                    bulkCopy.DestinationTableName = "Assets";
                                    bulkCopy.WriteToServer(dataTable);
                                }

                                // Replace existing data if needed
                                //string updateQuery = @"
                                //    MERGE INTO YourTableName AS Target
                                //    USING YourTempTable AS Source
                                //    ON Target.Id = Source.Id
                                //    WHEN MATCHED THEN 
                                //        UPDATE SET Target.Column1 = Source.Column1, Target.Column2 = Source.Column2
                                //    WHEN NOT MATCHED BY TARGET THEN
                                //        INSERT (Column1, Column2) VALUES (Source.Column1, Source.Column2);";


                                //using (SqlCommand command = new SqlCommand(updateQuery, connection, transaction))
                                //{
                                //    command.ExecuteNonQuery();
                                //}
                                // Commit the transaction if everything is successful
                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {
                                // Roll back the transaction if there is an error
                                transaction.Rollback();
                                Console.WriteLine($"Transaction rolled back due to an error: {ex.Message}");
                            }
                        }
                    }

                    return HttpStatusCode.OK;

                }
                catch (Exception)
                {

                    throw;
                }
                    

            }
        }

    }
}
