﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StocktakeModuleWorkerSerive.Models.Asset_Types;
using StocktakeModuleWorkerSerive.Models.Assets;
using StocktakeModuleWorkerSerive.Models.Locations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Controllers
{
    public class LocationController : Controller
    {
        private readonly ILogger<LocationController> _logger;
        public LocationController(ILogger<LocationController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<HttpStatusCode> GetLocations()
        {
            string BaseURL = "https://africanbank.freshservice.com";

            using (var client = new HttpClient())
            {
                int pageNumber = 1;
                var maxPagelength = false;
                client.BaseAddress = new Uri(BaseURL);
                client.DefaultRequestHeaders
                    .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                try
                {
                    List<Locations> locationDataList = new List<Locations>();

                    do
                    {
                        var URL = $"https://africanbank.freshservice.com/api/v2/locations?per_page=100&page={pageNumber}";

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, URL);

                        var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                        request.Content = new StringContent(JsonConvert.SerializeObject(""));
                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage Res = await client.SendAsync(request);

                        if (Res.IsSuccessStatusCode)
                        {
                            var response = Res.Content.ReadAsStringAsync().Result;

                            var locationStringObj = JsonConvert.DeserializeObject<LocationResultsObJ>(response);

                            if (locationStringObj.locations.Length > 0)
                            {
                                foreach (var locations in locationStringObj.locations)
                                {
                                    Locations location = new Locations();

                                    location.id = locations.id;
                                    location.name = locations.name;
                                    location.email = locations.email;
                                    location.parent_location_id = locations.parent_location_id;
                                    location.contact_name = locations.contact_name;
                                    location.primary_contact_id = locations.primary_contact_id;
                                    location.phone = locations.phone;
                                    location.created_at = locations.created_at;
                                    location.updated_at = locations.updated_at;
                                    location.address = locations.address;
                                    if (location.address != null && locations.address != null)
                                    {
                                        location.address.line1 = locations.address.line1;
                                        location.address.line2 = locations.address.line2;
                                        location.address.city = locations.address.city;
                                        location.address.state = locations.address.state;
                                        location.address.country = locations.address.country;
                                        location.address.zipcode = locations.address.zipcode;
                                    }
                                    else
                                        location.address = null;

                                    locationDataList.Add(location);
                                }

                                pageNumber++;
                            }
                            else
                                maxPagelength = true;


                        }
                        else
                            return HttpStatusCode.BadRequest;

                    } while (maxPagelength != true);

                    var loactionList = locationDataList;

                    var datTable = new DataTable();
                    datTable.Columns.Add(nameof(Locations.id), typeof(string));
                    datTable.Columns.Add(nameof(Locations.name), typeof(string));
                    datTable.Columns.Add(nameof(Locations.email), typeof(string));
                    datTable.Columns.Add(nameof(Locations.parent_location_id), typeof(string));
                    datTable.Columns.Add(nameof(Locations.contact_name), typeof(string));
                    datTable.Columns.Add(nameof(Locations.primary_contact_id), typeof(string));
                    datTable.Columns.Add(nameof(Locations.phone), typeof(string));
                    datTable.Columns.Add(nameof(Locations.created_at), typeof(string));
                    datTable.Columns.Add(nameof(Locations.updated_at), typeof(string));
                    datTable.Columns.Add(nameof(Locations.address.line1), typeof(string));
                    datTable.Columns.Add(nameof(Locations.address.line2), typeof(string));
                    datTable.Columns.Add(nameof(Locations.address.city), typeof(string));
                    datTable.Columns.Add(nameof(Locations.address.state), typeof(string));
                    datTable.Columns.Add(nameof(Locations.address.country), typeof(string));
                    datTable.Columns.Add(nameof(Locations.address.zipcode), typeof(string));

                    foreach (var location in loactionList)
                    {
                        datTable.Rows.Add(location.id,
                                          location.name,
                                          location.email,
                                          location.parent_location_id,
                                          location.contact_name,
                                          location.primary_contact_id,
                                          location.phone,
                                          location.created_at,
                                          location.updated_at,
                                          location.address.line1,
                                          location.address.line2,
                                          location.address.city,
                                          location.address.state,
                                          location.address.country,
                                          location.address.country);
                    }

                    string connectionString = "SERVER=mpwopsql3\\sql01;DATABASE=StockTakeModuleDB;user id=PGFE_Dev_User;password=palKnjhvifW4kb$;MultipleActiveResultSets=true;Initial Catalog=StockTakeModuleDB;";
                    DataTable dataTable = datTable;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        using (SqlTransaction transaction = connection.BeginTransaction())
                        {
                            try
                            {
                                string deleteQuery = "DELETE FROM Locations";

                                using (SqlCommand command = new SqlCommand(deleteQuery, connection, transaction))
                                {
                                    command.ExecuteNonQuery();
                                }

                                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.KeepIdentity, transaction))
                                {
                                    bulkCopy.DestinationTableName = "Locations";
                                    bulkCopy.WriteToServer(dataTable);
                                }

                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {

                                // Roll back the transaction if there is an error
                                transaction.Rollback();
                                Console.WriteLine($"Transaction rolled back due to an error: {ex.Message}");
                            }
                        }
                    }

                    return HttpStatusCode.OK;
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
    }
}
