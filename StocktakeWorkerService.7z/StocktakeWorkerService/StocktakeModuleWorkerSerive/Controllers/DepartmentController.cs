﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StocktakeModuleWorkerSerive.Models.Assets;
using StocktakeModuleWorkerSerive.Models.Departments;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly ILogger<DepartmentController> _logger;

        public DepartmentController(ILogger<DepartmentController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<HttpStatusCode> GetDepartments()
        {
            string BaseURL = "https://africanbank.freshservice.com";

            using(var client = new HttpClient())
            {
                int pageNumber = 1;
                var maxPagelength = false;
                client.BaseAddress = new Uri(BaseURL);
                client.DefaultRequestHeaders
                    .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                try
                {
                    List<Departments> departmentDataList = new List<Departments>();

                    do
                    {
                        var URL = $"https://africanbank.freshservice.com/api/v2/departments?per_page=100&page={pageNumber}";

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, URL);

                        var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                        request.Content = new StringContent(JsonConvert.SerializeObject(""));
                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage Res = await client.SendAsync(request);

                        if (Res.IsSuccessStatusCode)
                        {
                            var response = Res.Content.ReadAsStringAsync().Result;

                            var depStringObj = JsonConvert.DeserializeObject<DepartmentResultsObj>(response);

                            if(depStringObj.Departments.Length > 0)
                            {
                                foreach(var departments in depStringObj.Departments)
                                {
                                    Departments department = new Departments();
                                    
                                    department.id = departments.id;
                                    department.name = departments.name;
                                    department.description = departments.description;
                                    department.created_at = departments.created_at;
                                    department.updated_at = departments.updated_at;
                                    department.prime_user_id = departments.prime_user_id;
                                    department.head_user_id = departments.head_user_id;

                                    departmentDataList.Add(department);
                                }

                                pageNumber++;
                            }
                            else
                                maxPagelength = true;
                        }
                        else
                            return HttpStatusCode.BadRequest;

                    } while (maxPagelength != true);

                    var departmentList = departmentDataList;

                    var datTable = new DataTable();
                    datTable.Columns.Add(nameof(Departments.id), typeof(string));
                    datTable.Columns.Add(nameof(Departments.name), typeof(string));
                    datTable.Columns.Add(nameof(Departments.description), typeof(string));
                    datTable.Columns.Add(nameof(Departments.created_at), typeof(string));
                    datTable.Columns.Add(nameof(Departments.updated_at), typeof(string));
                    datTable.Columns.Add(nameof(Departments.prime_user_id), typeof(string));
                    datTable.Columns.Add(nameof(Departments.head_user_id), typeof(string));

                    foreach ( var department in departmentList)
                    {
                        datTable.Rows.Add(department.id,
                                          department.name,
                                          department.description,
                                          department.created_at,
                                          department.updated_at,
                                          department.prime_user_id,
                                          department.head_user_id);
                    }

                    string connectionString = "SERVER=mpwopsql3\\sql01;DATABASE=StockTakeModuleDB;user id=PGFE_Dev_User;password=palKnjhvifW4kb$;MultipleActiveResultSets=true;Initial Catalog=StockTakeModuleDB;";
                    DataTable dataTable = datTable;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        using (SqlTransaction transaction = connection.BeginTransaction())
                        {
                            try
                            {
                                string deleteQuery = "DELETE FROM Departments";

                                using (SqlCommand command = new SqlCommand(deleteQuery, connection, transaction))
                                {
                                    command.ExecuteNonQuery();
                                }

                                // Bulk insert new data
                                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.KeepIdentity, transaction))
                                {
                                    bulkCopy.DestinationTableName = "Departments";
                                    bulkCopy.WriteToServer(dataTable);
                                }

                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {

                                // Roll back the transaction if there is an error
                                transaction.Rollback();
                                Console.WriteLine($"Transaction rolled back due to an error: {ex.Message}");
                            }
                        }
                    }

                    return HttpStatusCode.OK;
                }
                catch (Exception)
                {

                   throw;
                }
            }
        }
    }
}
