﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StocktakeModuleWorkerSerive.Models.Departments;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using StocktakeModuleWorkerSerive.Models.Products;

namespace StocktakeModuleWorkerSerive.Controllers
{
    public class ProductController : Controller
    {
        private readonly ILogger<ProductController> _logger;

        public ProductController(ILogger<ProductController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public async Task<HttpStatusCode> GetProducts()
        {
            string BaseURL = "https://africanbank.freshservice.com";

            using (var client = new HttpClient())
            {
                int pageNumber = 1;
                var maxPagelength = false;
                client.BaseAddress = new Uri(BaseURL);
                client.DefaultRequestHeaders
                    .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                try
                {
                    List<Products> productDataList = new List<Products>();

                    do
                    {
                        var URL = $"https://africanbank.freshservice.com/api/v2/products?per_page=100&page={pageNumber}";

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, URL);

                        var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                        request.Content = new StringContent(JsonConvert.SerializeObject(""));
                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage Res = await client.SendAsync(request);

                        if (Res.IsSuccessStatusCode)
                        {
                            var response = Res.Content.ReadAsStringAsync().Result;

                            var prodStringObj = JsonConvert.DeserializeObject<ProductResultsData>(response);

                            if (prodStringObj.product.Length > 0)
                            {
                                foreach (var products in prodStringObj.product)
                                {
                                    Products product = new Products();

                                    product.id = products.id;
                                    product.name = products.name;
                                    product.depreciation_type_id = products.depreciation_type_id;
                                    product.description = products.description;
                                    product.description_text = product.description;
                                    product.created_at = products.created_at;
                                    product.updated_at = products.updated_at;
                                    product.asset_type_id = products.asset_type_id;
                                    product.manufacturer = products.manufacturer;
                                    product.status = products.status;
                                    product.mode_of_procurement = products.mode_of_procurement;
                                    

                                    productDataList.Add(product);
                                }

                                pageNumber++;
                            }
                            else
                                maxPagelength = true;
                        }
                        else
                            return HttpStatusCode.BadRequest;

                    } while (maxPagelength != true);

                    var productList = productDataList;

                    var datTable = new DataTable();
                    datTable.Columns.Add(nameof(Products.id), typeof(string));
                    datTable.Columns.Add(nameof(Products.name), typeof(string));
                    datTable.Columns.Add(nameof(Products.description), typeof(string));
                    datTable.Columns.Add(nameof(Products.description_text), typeof(string));
                    datTable.Columns.Add(nameof(Products.asset_type_id), typeof(string));
                    datTable.Columns.Add(nameof(Products.depreciation_type_id), typeof(string));
                    datTable.Columns.Add(nameof(Products.created_at), typeof(string));
                    datTable.Columns.Add(nameof(Products.updated_at), typeof(string));
                    datTable.Columns.Add(nameof(Products.manufacturer), typeof(string));
                    datTable.Columns.Add(nameof(Products.status), typeof(string));
                    datTable.Columns.Add(nameof(Products.mode_of_procurement), typeof(string));

                    foreach (var product in productList)
                    {
                        datTable.Rows.Add(product.id,
                                          product.name,
                                          product.description,
                                          product.description_text,
                                          product.asset_type_id,
                                          product.depreciation_type_id,
                                          product.created_at,
                                          product.updated_at,
                                          product.manufacturer,
                                          product.status,
                                          product.mode_of_procurement);
                    }

                    string connectionString = "SERVER=mpwopsql3\\sql01;DATABASE=StockTakeModuleDB;user id=PGFE_Dev_User;password=palKnjhvifW4kb$;MultipleActiveResultSets=true;Initial Catalog=StockTakeModuleDB;";
                    DataTable dataTable = datTable;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        using (SqlTransaction transaction = connection.BeginTransaction())
                        {
                            try
                            {
                                string deleteQuery = "DELETE FROM Products";

                                using (SqlCommand command = new SqlCommand(deleteQuery, connection, transaction))
                                {
                                    command.ExecuteNonQuery();
                                }

                                // Bulk insert new data
                                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.KeepIdentity, transaction))
                                {
                                    bulkCopy.DestinationTableName = "Products";
                                    bulkCopy.WriteToServer(dataTable);
                                }

                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {

                                // Roll back the transaction if there is an error
                                transaction.Rollback();
                                Console.WriteLine($"Transaction rolled back due to an error: {ex.Message}");
                            }
                        }
                    }

                    return HttpStatusCode.OK;
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
    }
}
