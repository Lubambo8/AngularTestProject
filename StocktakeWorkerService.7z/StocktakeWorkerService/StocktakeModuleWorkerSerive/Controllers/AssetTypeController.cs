﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StocktakeModuleWorkerSerive.Models.Asset_Types;
using StocktakeModuleWorkerSerive.Models.Products;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Controllers
{
    public class AssetTypeController : Controller
    {
        private readonly ILogger<AssetTypeController> _logger;
        public AssetTypeController(ILogger<AssetTypeController> logger)
        {
            _logger = logger;  
        }

        [HttpGet]
        public async Task<HttpStatusCode> GetAssetTypes()
        {
            string BaseURL = "https://africanbank.freshservice.com";

            using(var client = new HttpClient())
            {
                int pageNumber = 1;
                var maxPagelength = false;
                client.BaseAddress = new Uri(BaseURL);
                client.DefaultRequestHeaders
                    .Accept
                    .Add(new MediaTypeWithQualityHeaderValue("application/json"));

                try
                {
                    List<AssetType> assetTypeDataList = new List<AssetType>();

                    do
                    {
                        var URL = $"https://africanbank.freshservice.com/api/v2/asset_types?per_page=100&page={pageNumber}";

                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, URL);

                        var byteArray = Encoding.ASCII.GetBytes("I6VPAcHqDLZQx4xtUaCx:x");
                        client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                        request.Content = new StringContent(JsonConvert.SerializeObject(""));
                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage Res = await client.SendAsync(request);

                        if (Res.IsSuccessStatusCode)
                        {
                            var response = Res.Content.ReadAsStringAsync().Result;

                            var assetTypeStringObj = JsonConvert.DeserializeObject<AssetTypeResultsData>(response);

                            if (assetTypeStringObj.asset_type.Length > 0)
                            {
                                foreach(var assetTypes in assetTypeStringObj.asset_type)
                                {
                                    AssetType assetType = new AssetType();

                                    assetType.id = assetTypes.id;
                                    assetType.name = assetTypes.name;
                                    assetType.description = assetTypes.description;
                                    assetType.parent_asset_type_id = assetTypes.parent_asset_type_id;
                                    assetType.visible = assetTypes.visible;
                                    assetType.created_at = assetTypes.created_at;
                                    assetType.updated_at = assetTypes.updated_at;

                                    assetTypeDataList.Add(assetTypes);
                                }

                                pageNumber++;

                            }
                            else
                                maxPagelength = true;

                        }
                        else
                            return HttpStatusCode.BadRequest;


                    } while (maxPagelength != true);

                    var assetTypeList = assetTypeDataList;

                    var datTable = new DataTable();
                    datTable.Columns.Add(nameof(AssetType.id), typeof(string));
                    datTable.Columns.Add(nameof (AssetType.name), typeof(string));
                    datTable.Columns.Add(nameof(AssetType.description), typeof(string));
                    datTable.Columns.Add(nameof(AssetType.parent_asset_type_id), typeof(string));
                    datTable.Columns.Add(nameof(AssetType.visible), typeof(string));
                    datTable.Columns.Add(nameof(AssetType.created_at), typeof(string));
                    datTable.Columns.Add(nameof(AssetType.updated_at), typeof(string));
                    
                    foreach( var assetType in assetTypeList)
                    {
                        datTable.Rows.Add(assetType.id,
                                          assetType.name,
                                          assetType.description,
                                          assetType.parent_asset_type_id,
                                          assetType.visible,
                                          assetType.created_at,
                                          assetType.updated_at);
                    }

                    string connectionString = "SERVER=mpwopsql3\\sql01;DATABASE=StockTakeModuleDB;user id=PGFE_Dev_User;password=palKnjhvifW4kb$;MultipleActiveResultSets=true;Initial Catalog=StockTakeModuleDB;";
                    DataTable dataTable = datTable;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();

                        using (SqlTransaction transaction = connection.BeginTransaction())
                        {
                            try
                            {
                                string deleteQuery = "DELETE FROM AssetTypes";

                                using (SqlCommand command = new SqlCommand(deleteQuery, connection, transaction))
                                {
                                    command.ExecuteNonQuery();
                                }

                                // Bulk insert new data
                                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.KeepIdentity, transaction))
                                {
                                    bulkCopy.DestinationTableName = "AssetTypes";
                                    bulkCopy.WriteToServer(dataTable);
                                }

                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {
                                // Roll back the transaction if there is an error
                                transaction.Rollback();
                                Console.WriteLine($"Transaction rolled back due to an error: {ex.Message}");
                            }
                        }
                    }

                    return HttpStatusCode.OK;
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
    }
}
