using StocktakeModuleWorkerSerive.Controllers;
using System.Net;

namespace StocktakeModuleWorkerSerive
{
    public class Worker : BackgroundService
    {
        private readonly TimeSpan _period = TimeSpan.FromSeconds(10);
        private readonly ILogger<Worker> _logger;
        private readonly IServiceScopeFactory _scopeFactory;
        public bool isEnabled = true;

        public Worker(ILogger<Worker> logger, IServiceScopeFactory scopeFactory)
        {
            _logger = logger;
            _scopeFactory = scopeFactory;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            using PeriodicTimer timer = new PeriodicTimer(_period);
            while (!stoppingToken.IsCancellationRequested && await timer.WaitForNextTickAsync(stoppingToken))
            {
                _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
                try
                {
                    if (isEnabled)
                    {
                        await using AsyncServiceScope asyncScope = _scopeFactory.CreateAsyncScope();
                        AssetTypeController assetType = asyncScope.ServiceProvider.GetRequiredService<AssetTypeController>();
                        LocationController location = asyncScope.ServiceProvider.GetRequiredService<LocationController>();
                        ProductController product = asyncScope.ServiceProvider.GetRequiredService<ProductController>();
                        DepartmentController department = asyncScope.ServiceProvider.GetRequiredService<DepartmentController>();
                        AssetController asset = asyncScope.ServiceProvider.GetRequiredService<AssetController>();

                        var assetTypeCodeStatus = assetType.GetAssetTypes().Result;
                        if (assetTypeCodeStatus == HttpStatusCode.OK)
                        {
                            _logger.LogInformation("Worker running at: {time} and populated assetTypes", DateTimeOffset.Now);
                        }
                        else
                            _logger.LogInformation("Worker running at: {time} and could not populate assetType table in DB", DateTimeOffset.Now);

                        var locationCodeStatus = location.GetLocations().Result;
                        if (locationCodeStatus == HttpStatusCode.OK)
                        {
                            _logger.LogInformation("Worker running at: {time} and populated locations", DateTimeOffset.Now);
                        }
                        else
                            _logger.LogInformation("Worker running at: {time} and could not populate locations table in DB", DateTimeOffset.Now);


                        var prodCodeStatus = product.GetProducts().Result;
                        if (prodCodeStatus == HttpStatusCode.OK)
                        {
                            _logger.LogInformation("Worker running at: {time} and populated products", DateTimeOffset.Now);
                        }
                        else
                            _logger.LogInformation("Worker running at: {time} and could not populate product table in DB", DateTimeOffset.Now);

                        var depCodeStatus = department.GetDepartments().Result;
                        if (depCodeStatus == HttpStatusCode.OK)
                        {
                            _logger.LogInformation("Worker running at: {time} and populated departments", DateTimeOffset.Now);
                        }
                        else
                            _logger.LogInformation("Worker running at: {time} and could not populate department table in DB", DateTimeOffset.Now);

                        var assetCodeStatus = asset.GetAssets().Result;
                        if (assetCodeStatus == HttpStatusCode.OK)
                        {
                            _logger.LogInformation("Worker running at: {time} and populated assets", DateTimeOffset.Now);
                        }
                        else
                            _logger.LogInformation("Worker running at: {time} and could not populate asset table in DB", DateTimeOffset.Now);

                        isEnabled = false;
                    }
                    
                }
                catch (Exception ex)
                {

                    _logger.LogInformation(
                    $"Failed to execute Worker with exception message {ex.Message}. Good luck next round!");

                }

            }
        }
    }
}
