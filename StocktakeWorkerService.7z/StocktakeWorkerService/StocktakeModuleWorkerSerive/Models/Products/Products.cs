﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Products
{
    [DataContract]
    public class Products
    {
        [DataMember(Name = "id")]
        [JsonProperty("id")]
        public string? id { get; set; }
        [DataMember(Name = "name")]
        [JsonProperty("name")]
        public string? name { get; set; }
        [DataMember(Name = "asset_type_id")]
        [JsonProperty("asset_type_id")]
        public string? asset_type_id { get; set; }
        [DataMember(Name = "manufacturer")]
        [JsonProperty("manufacturer")]
        public string? manufacturer { get; set; }
        [DataMember(Name = "status")]
        [JsonProperty("status")]
        public string? status { get; set; }
        [DataMember(Name = "mode_of_procurement")]
        [JsonProperty("mode_of_procurement")]
        public string? mode_of_procurement { get; set; }
        [DataMember(Name = "depreciation_type_id")]
        [JsonProperty("depreciation_type_id")]
        public string? depreciation_type_id { get; set; }
        [DataMember(Name = "description")]
        [JsonProperty("description")]
        public string? description { get; set; }
        [DataMember(Name = "description_text")]
        [JsonProperty("description_text")]
        public string? description_text { get; set; }
        [DataMember(Name = "created_at")]
        [JsonProperty("created_at")]
        public string? created_at { get; set; }
        [DataMember(Name = "updated_at")]
        [JsonProperty("updated_at")]
        public string? updated_at { get; set; }
    }
}
