﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Asset_Types
{
    [DataContract]
    public class AssetTypeResultsData
    {
        [DataMember(Name = "asset_types")]
        [JsonProperty("asset_types")]
        public AssetType[]? asset_type { get; set; }
    }
}
