﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Asset_Types
{
    [DataContract]
    public class AssetType
    {
        [DataMember(Name = "id")]
        [JsonProperty("id")]
        public string? id { get; set; }
        [DataMember(Name = "name")]
        [JsonProperty("name")]
        public string? name { get; set; }
        [DataMember(Name = "description")]
        [JsonProperty("description")]
        public string? description { get; set; }
        [DataMember(Name = "parent_asset_type_id")]
        [JsonProperty("parent_asset_type_id")]
        public string? parent_asset_type_id { get; set; }
        [DataMember(Name = "visible")]
        [JsonProperty("visible")]
        public string? visible { get; set; }
        [DataMember(Name = "created_at")]
        [JsonProperty("created_at")]
        public string? created_at { get; set; }
        [DataMember(Name = "updated_at")]
        [JsonProperty("updated_at")]
        public string? updated_at { get; set; }
    }
}
