﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Departments
{
    [DataContract]
    public class Departments
    {
        [DataMember(Name = "description")]
        [JsonProperty("description")]
        public string? description { get; set; }

        [DataMember(Name = "id")]
        [JsonProperty("id")]
        public string? id { get; set; }

        [DataMember(Name = "name")]
        [JsonProperty("name")]
        public string? name { get; set; }

        [DataMember(Name = "created_at")]
        [JsonProperty("created_at")]
        public string? created_at { get; set; }

        [DataMember(Name = "updated_at")]
        [JsonProperty("updated_at")]
        public string? updated_at { get; set; }

        [DataMember(Name = "prime_user_id")]
        [JsonProperty("prime_user_id")]
        public string? prime_user_id { get; set; }

        [DataMember(Name = "head_user_id")]
        [JsonProperty("head_user_id")]
        public string? head_user_id { get; set; }
    } 
}
