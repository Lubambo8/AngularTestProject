﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Locations
{
    [DataContract]
    public class Locations
    {
        [DataMember(Name = "address")]
        [JsonProperty("address")]
        public Address? address { get; set; }
        [DataMember(Name = "contact_name")]
        [JsonProperty("contact_name")]
        public string? contact_name { get; set; }
        [DataMember(Name = "created_at")]
        [JsonProperty("created_at")]
        public string? created_at { get; set; }
        [DataMember(Name = "email")]
        [JsonProperty("email")]
        public string? email { get; set; }
        [DataMember(Name = "id")]
        [JsonProperty("id")]
        public string? id { get; set; }
        [DataMember(Name = "name")]
        [JsonProperty("name")]
        public string? name { get; set; }
        [DataMember(Name = "parent_location_id")]
        [JsonProperty("parent_location_id")]
        public string? parent_location_id { get; set; }
        [DataMember(Name = "phone")]
        [JsonProperty("phone")]
        public string? phone { get; set; }
        [DataMember(Name = "primary_contact_id")]
        [JsonProperty("primary_contact_id")]
        public string? primary_contact_id { get; set; }
        [DataMember(Name = "updated_at")]
        [JsonProperty("updated_at")]
        public string? updated_at { get; set; }
    }
}
