﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Locations
{
    [DataContract]
    public class Address
    {
        [DataMember(Name = "line1")]
        [JsonProperty("line1")]
        public string? line1 { get; set; }
        [DataMember(Name = "line2")]
        [JsonProperty("line2")]
        public string? line2 { get; set; }
        [DataMember(Name = "city")]
        [JsonProperty("city")]
        public string? city { get; set; }
        [DataMember(Name = "state")]
        [JsonProperty("state")]
        public string? state { get; set; }
        [DataMember(Name = "country")]
        [JsonProperty("country")]
        public string? country { get; set; }
        [DataMember(Name = "zipcode")]
        [JsonProperty("zipcode")]
        public string? zipcode { get; set; }
    }
}
