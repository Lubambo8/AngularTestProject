﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Locations
{
    [DataContract]
    public class LocationResultsObJ
    {
        [DataMember(Name = "locations")]
        [JsonProperty("locations")]
        public Locations[]? locations { get; set; }
    }
}
