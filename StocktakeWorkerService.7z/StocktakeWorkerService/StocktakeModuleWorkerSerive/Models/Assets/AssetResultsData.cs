﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Assets
{
    [DataContract]
    public class AssetResultsData
    {
        [DataMember(Name = "assets")]
        [JsonProperty("assets")]
        public Assets[]? assets { get; set; }
    }
}
