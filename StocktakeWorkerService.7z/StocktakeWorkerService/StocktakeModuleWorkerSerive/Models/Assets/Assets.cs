﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Assets
{
    [DataContract]
    public class Assets
    {
        [DataMember(Name = "id")]
        [JsonProperty("id")]
        [Key]
        public string? id { get; set; }
        [DataMember(Name = "display_id")]
        [JsonProperty("display_id")]
        public string? display_id { get; set; }
        [DataMember(Name = "name")]
        [JsonProperty("name")]
        public string? name { get; set; }
        [DataMember(Name = "description")]
        [JsonProperty("description")]
        public string? description { get; set; }
        [DataMember(Name = "asset_type_id")]
        [JsonProperty("asset_type_id")]
        public string? asset_type_id { get; set; }
        [DataMember(Name = "impact")]
        [JsonProperty("impact")]
        public string? impact { get; set; }
        [DataMember(Name = "author_type")]
        [JsonProperty("author_type")]
        public string? author_type { get; set; }
        [DataMember(Name = "usage_type")]
        [JsonProperty("usage_type")]
        public string? usage_type { get; set; }
        [DataMember(Name = "asset_tag")]
        [JsonProperty("asset_tag")]
        public string? asset_tag { get; set; }
        [DataMember(Name = "user_id")]
        [JsonProperty("user_id")]
        public string? user_id { get; set; }
        [DataMember(Name = "department_id")]
        [JsonProperty("department_id")]
        public string? department_id { get; set; }
        [DataMember(Name = "location_id")]
        [JsonProperty("location_id")]
        public string? location_id { get; set; }
        [DataMember(Name = "agent_id")]
        [JsonProperty("agent_id")]
        public string? agent_id { get; set; }
        [DataMember(Name = "group_id")]
        [JsonProperty("group_id")]
        public string? group_id { get; set; }
        [DataMember(Name = "assigned_on")]
        [JsonProperty("assigned_on")]
        public string? assigned_on { get; set; }
        [DataMember(Name = "created_at")]
        [JsonProperty("created_at")]
        public string? created_at { get; set; }
        [DataMember(Name = "updated_at")]
        [JsonProperty("updated_at")]
        public string? updated_at { get; set; }

        [DataMember(Name = "type_fields")]
        [JsonProperty("type_fields")]
        public TypeFields? type_fields { get; set; }
    }
}
