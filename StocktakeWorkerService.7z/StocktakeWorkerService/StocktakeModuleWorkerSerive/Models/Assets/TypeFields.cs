﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace StocktakeModuleWorkerSerive.Models.Assets
{
    [DataContract]
    public class TypeFields
    {
        [DataMember(Name = "product_50000156930")]
        [JsonProperty("product_50000156930")]
        public string? product_50000156930 { get; set; }
        [DataMember(Name = "vendor_50000156930")]
        [JsonProperty("vendor_50000156930")]
        public string? vendor_50000156930 { get; set; }
        [DataMember(Name = "virtual_host_50000156930")]
        [JsonProperty("virtual_host_50000156930")]
        public string? virtual_host_50000156930 { get; set; }
        [DataMember(Name = "cost_50000156930")]
        [JsonProperty("cost_50000156930")]
        public string? cost_50000156930 { get; set; }
        [DataMember(Name = "stock_take_date_50000156930")]
        [JsonProperty("stock_take_date_50000156930")]
        public string? stock_take_date_50000156930 { get; set; }
        [DataMember(Name = "stock_take_date_50000156931")]
        [JsonProperty("stock_take_date_50000156931")]
        public string? stock_take_date_50000156931 { get; set; }
        [DataMember(Name = "cost_code_50000156930")]
        [JsonProperty("cost_code_50000156930")]
        public string? cost_code_50000156930 { get; set; }
        [DataMember(Name = "reporting_manager_50000156930")]
        [JsonProperty("reporting_manager_50000156930")]
        public string? reporting_manager_50000156930 { get; set; }
        [DataMember(Name = "warranty_50000156930")]
        [JsonProperty("warranty_50000156930")]
        public string? warranty_50000156930 { get; set; }
        [DataMember(Name = "acquisition_date_50000156930")]
        [JsonProperty("acquisition_date_50000156930")]
        public string? acquisition_date_50000156930 { get; set; }
        [DataMember(Name = "warranty_expiry_date_50000156930")]
        [JsonProperty("warranty_expiry_date_50000156930")]
        public string? warranty_expiry_date_50000156930 { get; set; }
        [DataMember(Name = "domain_50000156930")]
        [JsonProperty("domain_50000156930")]
        public string? domain_50000156930 { get; set; }
        [DataMember(Name = "asset_state_50000156930")]
        [JsonProperty("asset_state_50000156930")]
        public string? asset_state_50000156930 { get; set; }
        [DataMember(Name = "serial_number_50000156930")]
        [JsonProperty("serial_number_50000156930")]
        public string? serial_number_50000156930 { get; set; }
        [DataMember(Name = "last_audit_date_50000156930")]
        [JsonProperty("last_audit_date_50000156930")]
        public string? last_audit_date_50000156930 { get; set; }
        [DataMember(Name = "os_50000156935")]
        [JsonProperty("os_50000156935")]
        public string? os_50000156935 { get; set; }
        [DataMember(Name = "os_version_50000156935")]
        [JsonProperty("os_version_50000156935")]
        public string? os_version_50000156935 { get; set; }
        [DataMember(Name = "os_service_pack_50000156935")]
        [JsonProperty("os_service_pack_50000156935")]
        public string? os_service_pack_50000156935 { get; set; }
        [DataMember(Name = "memory_50000156935")]
        [JsonProperty("memory_50000156935")]
        public string? memory_50000156935 { get; set; }
        [DataMember(Name = "disk_space_50000156935")]
        [JsonProperty("disk_space_50000156935")]
        public string? disk_space_50000156935 { get; set; }
        [DataMember(Name = "cpu_speed_50000156935")]
        [JsonProperty("cpu_speed_50000156935")]
        public string? cpu_speed_50000156935 { get; set; }
        [DataMember(Name = "total_cpus_50000156935")]
        [JsonProperty("total_cpus_50000156935")]
        public string? total_cpus_50000156935 { get; set; }
        [DataMember(Name = "cpu_core_count_50000156935")]
        [JsonProperty("cpu_core_count_50000156935")]
        public string? cpu_core_count_50000156935 { get; set; }
        [DataMember(Name = "mac_address_50000156935")]
        [JsonProperty("mac_address_50000156935")]
        public string? mac_address_50000156935 { get; set; }
        [DataMember(Name = "uuid_50000156935")]
        [JsonProperty("uuid_50000156935")]
        public string? uuid_50000156935 { get; set; }
        [DataMember(Name = "hostname_50000156935")]
        [JsonProperty("hostname_50000156935")]
        public string? hostname_50000156935 { get; set; }
        [DataMember(Name = "computer_ip_address_50000156935")]
        [JsonProperty("computer_ip_address_50000156935")]
        public string? computer_ip_address_50000156935 { get; set; }
        [DataMember(Name = "last_login_by_50000156935")]
        [JsonProperty("last_login_by_50000156935")]
        public string? last_login_by_50000156935 { get; set; }

        [DataMember(Name = "depreciation_id")]
        [JsonProperty("depreciation_id")]
        public string? depreciation_id { get; set; }

        [DataMember(Name = "salvage")]
        [JsonProperty("salvage")]
        public string? salvage { get; set; }

        [DataMember(Name = "state_50000156931")]
        [JsonProperty("state_50000156931")]
        public string? state_50000156931 { get; set; }

        [DataMember(Name = "quantity_50000156931")]
        [JsonProperty("quantity_50000156931")]
        public string? quantity_50000156931 { get; set; }

        [DataMember(Name = "product_50000156931")]
        [JsonProperty("product_50000156931")]
        public string? product_50000156931 { get; set; }

    }
}
